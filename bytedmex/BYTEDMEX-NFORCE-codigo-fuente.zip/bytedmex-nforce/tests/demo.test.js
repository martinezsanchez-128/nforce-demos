import test from 'node:test';
import assert from 'node:assert/strict';
import { calculateCart } from '../src/web/demo.js';
const products = [
  { id: 'pc', name: 'PC', price: 1000000, stock: 3, image: 'pc.webp' },
  { id: 'mouse', name: 'Mouse', price: 100000, stock: 2, image: 'mouse.webp' },
  { id: 'empty', name: 'Agotado', price: 100000, stock: 0, image: 'empty.webp' },
];
test('carrito usa los precios del catálogo, ignora importes manipulados', () => {
  const q = calculateCart(products, [{ id: 'pc', quantity: 1, price: 1, total: 1 }]);
  assert.equal(q.total, 1000000);
});
test('NFORCE10 descuenta 10% y conserva envío gratis', () => {
  const q = calculateCart(products, [{ id: 'pc', quantity: 1 }], 'nforce10');
  assert.equal(q.discount, 100000);
  assert.equal(q.total, 900000);
  assert.equal(q.shipping, 0);
});
test('SETUP500 aplica descuento fijo al superar el mínimo', () => {
  const q = calculateCart(products, [{ id: 'pc', quantity: 1 }], 'SETUP500');
  assert.equal(q.total, 950000);
});
test('SETUP500 rechaza compras bajo el mínimo', () =>
  assert.throws(() => calculateCart(products, [{ id: 'mouse', quantity: 1 }], 'SETUP500')));
test('envío ficticio cuesta 149 MXN bajo el umbral', () =>
  assert.equal(calculateCart(products, [{ id: 'mouse', quantity: 1 }]).shipping, 14900));
test('cupones inexistentes se rechazan', () =>
  assert.throws(() => calculateCart(products, [{ id: 'pc', quantity: 1 }], 'FAKE')));
test('productos agotados y cantidades mayores al stock se rechazan', () => {
  assert.throws(() => calculateCart(products, [{ id: 'empty', quantity: 1 }]));
  assert.throws(() => calculateCart(products, [{ id: 'pc', quantity: 4 }]));
});
test('no admite duplicados ni cantidades negativas, fraccionadas o productos desconocidos', () => {
  for (const items of [
    [
      { id: 'pc', quantity: 1 },
      { id: 'pc', quantity: 1 },
    ],
    [{ id: 'pc', quantity: -1 }],
    [{ id: 'pc', quantity: 1.5 }],
    [{ id: 'unknown', quantity: 1 }],
  ])
    assert.throws(() => calculateCart(products, items));
});
test('carrito vacío no tiene cargos', () => assert.equal(calculateCart(products, []).total, 0));
