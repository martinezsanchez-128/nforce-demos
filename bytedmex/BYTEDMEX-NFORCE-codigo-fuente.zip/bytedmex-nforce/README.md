# BYTEDMEX · Demo ecommerce de NFORCE

Demostración interactiva para la sección de diseños de **NFORCE Technologies**.
El proyecto es estático y está preparado para publicarse en GitHub Pages.
Todos los productos, precios, especificaciones, existencias y pedidos son ficticios.

## Qué se puede probar

- Catálogo de 20 productos y 12 imágenes generadas por IA, alojadas localmente en WebP.
- Búsqueda, categorías, subcategorías, filtros por características y orden por precio.
- Fichas de producto y comparador de hasta tres productos.
- Carrito persistente, cantidades limitadas por el inventario ficticio y cupones.
- Checkout con datos de muestra precargados, sin solicitar tarjetas ni procesar pagos.
- Pedidos guardados localmente y panel demo para inventario y estados logísticos.
- Contacto real con NFORCE mediante WhatsApp, correo y sitio oficial.
- Video original ligado al scroll, animaciones GSAP y modo de movimiento reducido.

No requiere API, base de datos, variables de entorno, cuentas o secretos.
Los cambios de cada visitante solo afectan a su propio navegador.

## Ejecutar en desarrollo

Requiere Node.js 24 y npm.

```sh
npm ci
npm run dev
```

Abrir `http://127.0.0.1:4173`. Para verificar y compilar:

```sh
npm test
npm run build
npm run preview
```

La carpeta `dist/` contiene el sitio listo para publicar. Debe servirse por HTTP;
abrir `index.html` directamente con `file://` no es una prueba válida de módulos web.

## Publicar en GitHub Pages

### Con el código fuente y GitHub Actions

1. Crea un repositorio y sube **el contenido de esta carpeta** a su raíz, incluyendo
   `.github/workflows/pages.yml`, `package.json`, `package-lock.json`, `src/` y `public/`.
2. En **Settings → Pages → Build and deployment → Source**, selecciona **GitHub Actions**.
3. Usa la rama `main`. El workflow instala, ejecuta las pruebas, compila y publica `dist/`.
4. La URL se mostrará en el resultado del workflow y en Settings → Pages.

La configuración `base: './'` y las rutas con hash permiten alojar la demo en la raíz
o bajo una subcarpeta, sin conocer por adelantado el nombre del repositorio.

### Con el paquete ya compilado

Extrae `BYTEDMEX-NFORCE-GitHub-Pages.zip` y sube **su contenido**, no el ZIP, a la
raíz de una rama de publicación. Debe quedar `index.html` junto a `assets/` e `images/`.
Selecciona esa rama y `/ (root)` en Settings → Pages → Deploy from a branch.
Esta opción no necesita Node en el alojamiento.

## Integrar en la sección «Diseños» de NFORCE

En `docs/INTEGRACION.html` hay una tarjeta de ejemplo y una opción de iframe.
Sustituye `URL_PUBLICA_DE_LA_DEMO` por la URL que GitHub Pages entregue al publicar.
Las rutas útiles son `/#home`, `/#catalog`, `/#contact` y `/#admin`.

No se publicó en una cuenta de GitHub durante esta entrega: todavía no se indicó
un repositorio de destino.

## Dónde modificar cada cosa

```text
src/web/
  App.tsx          Navegación, composición de tienda y estado local
  catalog.ts       Productos ficticios, categorías y contacto de NFORCE
  demo.js          Cálculo de carrito, cupones y almacenamiento
  Cart.tsx         Carrito y checkout de prueba
  Dashboard.tsx    Inventario y gestión de pedidos ficticios
  Contact.tsx      Sección de contacto con NFORCE
  Facets.tsx       Filtros de catálogo
  Primitives.tsx   Tarjeta de producto y modal accesible
  Motion.tsx       Video y animaciones GSAP/Lenis
  Info.tsx         Avisos de la demostración y privacidad
  types.ts         Tipos compartidos y formato de importes
  styles.css       Sistema visual de BYTEDMEX
  portfolio.css    Contacto, checkout y adaptación al portafolio
public/images/     Fotografías de IA optimizadas
tests/             Pruebas de lógica de carrito
.github/workflows/ Publicación automática
```

Para reiniciar la experiencia, usa **Panel demo → Restablecer demo**. Se restablecen
solo las claves de esta aplicación; no se limpia el almacenamiento de otros sitios.
Si el navegador bloquea localStorage, la experiencia sigue funcionando durante la
sesión, pero no conservará cambios al recargar.

## Contacto publicado

Datos consultados en [el sitio oficial de NFORCE](https://nforcetechnologies.com.mx/):

- WhatsApp: +52 81 3594 5656.
- Correo: cdms28@hotmail.com.
- Sitio: https://nforcetechnologies.com.mx/.

Los mensajes de WhatsApp se rellenan con el contexto de la demo; el visitante
decide si los envía desde WhatsApp.

## Recursos visuales

Las doce fotografías de productos se generaron con la herramienta integrada de
imágenes. Los prompts y la correspondencia de archivos están en `docs/IMAGENES-IA.md`.
Algunos modelos ficticios comparten fotografía porque representan variantes del
mismo concepto de producto.

El video conserva la URL CloudFront de la referencia proporcionada por el usuario.
Se muestra un póster local si el video no carga. Las fuentes se cargan desde Google
Fonts. Estos recursos externos requieren conexión; el catálogo utiliza imágenes locales.

## Referencias de publicación

- [Workflows de GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages).
- [Despliegue estático de Vite](https://vite.dev/guide/static-deploy.html).
