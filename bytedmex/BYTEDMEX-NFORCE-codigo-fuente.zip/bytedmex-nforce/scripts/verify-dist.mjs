import {readFileSync,existsSync,readdirSync,statSync} from 'node:fs';
import {resolve,join} from 'node:path';
const root=resolve('dist');const html=readFileSync(join(root,'index.html'),'utf8');
for(const[,url]of html.matchAll(/(?:src|href)="([^"]+)"/g)){
  if(/^(https?:|data:|#)/.test(url))continue;
  if(url.startsWith('/'))throw new Error(`Ruta absoluta incompatible con subcarpetas: ${url}`);
  if(!existsSync(resolve(root,url)))throw new Error(`Recurso ausente: ${url}`);
}
const assets=['pc-noir','pc-arctic','gpu','mainboard','memory','monitor','keyboard','headset','cpu','ssd','mouse','hub'];
for(const name of assets)if(!existsSync(join(root,'images',`${name}.webp`)))throw new Error(`Imagen ausente: ${name}`);
if(!existsSync(join(root,'.nojekyll')))throw new Error('Falta .nojekyll');
let bytes=0;function size(directory){for(const name of readdirSync(directory)){const path=join(directory,name);const stat=statSync(path);if(stat.isDirectory())size(path);else bytes+=stat.size;}}size(root);
console.log(`Verificación estática: recursos relativos válidos, 12 imágenes locales, ${(bytes/1048576).toFixed(2)} MB en total.`);
