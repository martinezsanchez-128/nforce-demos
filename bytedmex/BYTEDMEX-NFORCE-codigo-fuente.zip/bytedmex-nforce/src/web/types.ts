export interface Product {
  id: string;
  sku: string;
  name: string;
  brand: string;
  model: string;
  category: string;
  subcategory: string;
  variant: string;
  parent_id?: string | null;
  description: string;
  specs: Record<string, string>;
  image: string;
  price: number;
  previousPrice?: number;
  stock: number;
  availability: string;
  demo: boolean;
  featured: boolean;
  warranty: string;
  updated: string;
}
export interface CartLine {
  id: string;
  quantity: number;
}
export interface DemoOrder {
  id: string;
  created: string;
  status: 'confirmed' | 'preparing' | 'shipped' | 'delivered' | 'cancelled';
  items: { id: string; name: string; quantity: number; price: number; image: string }[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  coupon: string;
  customer: string;
}
export interface Category {
  id: string;
  name: string;
}
export const money = (cents: number) =>
  new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    maximumFractionDigits: 2,
  }).format(cents / 100);
export const statusLabels: Record<string, string> = {
  confirmed: 'Demo confirmada',
  preparing: 'En preparación (demo)',
  shipped: 'Enviado (demo)',
  delivered: 'Entregado (demo)',
  cancelled: 'Cancelado (demo)',
};
