import type { Product, CartLine } from './types';
export function calculateCart(
  products: Product[],
  cart: CartLine[],
  coupon?: string,
): {
  items: { id: string; name: string; price: number; quantity: number; image: string }[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  coupon: string;
};
export function readLocal<T>(key: string, fallback: T): T;
export function writeLocal(key: string, value: unknown): boolean;
