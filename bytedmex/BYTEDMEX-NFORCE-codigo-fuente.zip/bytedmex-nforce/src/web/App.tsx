import { ProductCard, Empty, Modal } from './Primitives';
import { CartSummary, Checkout } from './Cart';
import { Contact } from './Contact';
import { Dashboard } from './Dashboard';
import { Info } from './Info';
import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import {
  ArrowRight,
  ArrowUpRight,
  Search,
  ShoppingBag,
  Menu,
  X,
  Cpu,
  Monitor,
  Mouse,
  Headphones,
  Plus,
  Minus,
  Trash2,
  GitCompareArrows,
  Check,
  Package,
  Truck,
  MessageCircle,
  SlidersHorizontal,
  UserRound,
} from 'lucide-react';
import { Hero, Story, SmoothScrollProvider } from './Motion';
import { initialCatalog, categories, NFORCE, contactUrl } from './catalog';
import { Facets, matchesFilters, emptyFilters } from './Facets';
import { readLocal, writeLocal } from './demo.js';
import { money, statusLabels, type Product, type CartLine, type DemoOrder } from './types';

const KEYS = {
  catalog: 'nforce-bytedmex-catalog-v1',
  cart: 'nforce-bytedmex-cart-v1',
  orders: 'nforce-bytedmex-orders-v1',
};
function Logo() {
  return (
    <a className="logo" href="#home" aria-label="BYTEDMEX, inicio">
      <Cpu size={24} strokeWidth={1.4} />
      <span>
        BYTE<b>DM</b>EX<small>ELEVA TU SETUP</small>
      </span>
    </a>
  );
}
export function App() {
  return (
    <SmoothScrollProvider>
      <Storefront />
    </SmoothScrollProvider>
  );
}
function Storefront() {
  const [route, setRoute] = useState(location.hash.slice(1) || 'home');
  const [products, setProducts] = useState<Product[]>(() => {
    const saved = readLocal<Product[]>(KEYS.catalog, initialCatalog);
    return Array.isArray(saved) &&
      saved.length &&
      saved.every(
        (p) =>
          p.id &&
          p.specs &&
          Number.isSafeInteger(p.price) &&
          p.price >= 0 &&
          Number.isInteger(p.stock) &&
          p.stock >= 0,
      )
      ? saved
      : initialCatalog;
  });
  const [cart, setCart] = useState<CartLine[]>(() => {
    const saved = readLocal<CartLine[]>(KEYS.cart, []);
    return Array.isArray(saved)
      ? saved.filter(
          (i) =>
            typeof i.id === 'string' &&
            Number.isInteger(i.quantity) &&
            i.quantity > 0 &&
            i.quantity <= 10,
        )
      : [];
  });
  const [orders, setOrders] = useState<DemoOrder[]>(() => {
    const saved = readLocal<DemoOrder[]>(KEYS.orders, []);
    return Array.isArray(saved) ? saved : [];
  });
  const [query, setQuery] = useState(''),
    [category, setCategory] = useState(''),
    [filters, setFilters] = useState(emptyFilters),
    [sort, setSort] = useState('featured'),
    [drawer, setDrawer] = useState(false),
    [selected, setSelected] = useState<Product | null>(null),
    [compare, setCompare] = useState<string[]>([]),
    [notice, setNotice] = useState(''),
    [coupon, setCoupon] = useState('');
  useEffect(() => {
    const navigate = () => {
      setRoute(location.hash.slice(1) || 'home');
      setDrawer(false);
      window.scrollTo(0, 0);
    };
    addEventListener('hashchange', navigate);
    return () => removeEventListener('hashchange', navigate);
  }, []);
  useEffect(() => {
    writeLocal(KEYS.catalog, products);
  }, [products]);
  useEffect(() => {
    writeLocal(KEYS.cart, cart);
  }, [cart]);
  useEffect(() => {
    writeLocal(KEYS.orders, orders);
  }, [orders]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(''), 4500);
    return () => clearTimeout(timer);
  }, [notice]);
  function browse(id = '') {
    setCategory(id);
    setFilters(emptyFilters);
    setQuery('');
    location.hash = 'catalog';
  }
  function add(product: Product) {
    if (!product.stock) {
      setNotice('Este producto está agotado en el inventario ficticio');
      return;
    }
    const line = cart.find((i) => i.id === product.id);
    if (line && line.quantity >= Math.min(10, product.stock)) {
      setNotice('Alcanzaste la cantidad disponible en la demo');
      return;
    }
    setCart((items) =>
      line
        ? items.map((i) => (i.id === product.id ? { ...i, quantity: i.quantity + 1 } : i))
        : [...items, { id: product.id, quantity: 1 }],
    );
    setNotice(`${product.name} agregado al carrito`);
  }
  function toggleCompare(id: string) {
    setCompare((current) =>
      current.includes(id) ? current.filter((i) => i !== id) : [...current, id].slice(-3),
    );
  }
  function reset() {
    if (
      !confirm(
        '¿Restablecer los productos, carrito y pedidos de esta demostración en tu navegador?',
      )
    )
      return;
    setProducts(initialCatalog);
    setCart([]);
    setOrders([]);
    setCoupon('');
    setNotice('Demostración restablecida');
  }
  const visible = products
    .filter(
      (p) =>
        (!category || p.category === category) &&
        matchesFilters(p, filters) &&
        `${p.name} ${p.brand} ${p.model} ${p.subcategory} ${Object.values(p.specs).join(' ')}`
          .toLowerCase()
          .includes(query.toLowerCase()),
    )
    .sort((a, b) =>
      sort === 'low'
        ? a.price - b.price
        : sort === 'high'
          ? b.price - a.price
          : Number(b.featured) - Number(a.featured),
    );
  const count = cart.reduce((sum, i) => sum + i.quantity, 0);
  function card(product: Product) {
    return (
      <ProductCard
        key={product.id}
        product={product}
        add={add}
        select={setSelected}
        compared={compare.includes(product.id)}
        compare={() => toggleCompare(product.id)}
      />
    );
  }
  return (
    <div className="app-shell">
      <div className="announcement">
        <span>DISEÑO INTERACTIVO POR NFORCE</span>
        <a href={NFORCE.website} target="_blank" rel="noreferrer">
          ¿QUIERES UNA WEB ASÍ? <ArrowUpRight size={12} />
        </a>
      </div>
      <header className="navbar">
        <Logo />
        <nav aria-label="Navegación principal">
          <a className={route === 'home' ? 'active' : ''} href="#home">
            Inicio
          </a>
          <button onClick={() => browse('computers')}>PC gamer</button>
          <button onClick={() => browse('components')}>Componentes</button>
          <button onClick={() => browse('peripherals')}>Periféricos</button>
          <button onClick={() => browse('monitors')}>Monitores</button>
        </nav>
        <div className="nav-actions">
          <button
            aria-label="Buscar productos"
            onClick={() => {
              browse();
              setTimeout(() => document.getElementById('search')?.focus(), 100);
            }}
          >
            <Search size={20} />
          </button>
          <a href="#orders" aria-label="Mis pedidos de prueba">
            <UserRound size={20} />
          </a>
          <a href="#cart" className="cart-button" aria-label={`Carrito, ${count} productos`}>
            <ShoppingBag size={20} />
            <span>{count}</span>
          </a>
          <motion.button
            className="mobile-menu"
            whileTap={{ scale: 0.95 }}
            aria-label={drawer ? 'Cerrar menú' : 'Abrir menú'}
            aria-expanded={drawer}
            onClick={() => setDrawer(!drawer)}
          >
            {drawer ? <X /> : <Menu />}
          </motion.button>
        </div>
      </header>
      <AnimatePresence>
        {drawer && (
          <motion.nav
            className="mobile-drawer"
            initial={{ clipPath: 'inset(0 0 100% 0)' }}
            animate={{ clipPath: 'inset(0 0 0% 0)' }}
            exit={{ clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          >
            <a href="#catalog">Catálogo</a>
            <a href="#orders">Pedidos de prueba</a>
            <a href="#admin">Panel de demostración</a>
            <a href="#contact">Contactar con NFORCE</a>
          </motion.nav>
        )}
      </AnimatePresence>
      <main>
        {route === 'home' && (
          <>
            <Hero onBrowse={browse} />
            <div className="trust-strip">
              <span>
                <Cpu /> 20 productos conceptuales
              </span>
              <span>
                <Package /> Inventario de demostración
              </span>
              <span>
                <Truck /> Checkout sin cobros
              </span>
              <span>
                <Headphones /> Diseño por NFORCE
              </span>
            </div>
            <section className="section categories">
              <div className="section-heading">
                <div>
                  <span className="eyebrow">TU SETUP EMPIEZA AQUÍ</span>
                  <h2>
                    Encuentra tu <em>siguiente upgrade.</em>
                  </h2>
                </div>
                <button className="text-link" onClick={() => browse()}>
                  Explorar catálogo <ArrowUpRight size={17} />
                </button>
              </div>
              <div className="category-grid">
                {categories.map((c, i) => (
                  <button key={c.id} onClick={() => browse(c.id)}>
                    <span className="category-index">0{i + 1}</span>
                    {[<Cpu />, <Cpu />, <Mouse />, <Monitor />, <Plus />][i]}
                    <strong>{c.name}</strong>
                    <ArrowUpRight size={17} />
                  </button>
                ))}
              </div>
            </section>
            <section className="section featured">
              <div className="section-heading">
                <div>
                  <span className="eyebrow">SELECCIÓN BYTEDMEX</span>
                  <h2>
                    Hechos para <em>dar más.</em>
                  </h2>
                </div>
                <span className="demo-label">PRODUCTOS E IMÁGENES CONCEPTUALES</span>
              </div>
              <div className="product-grid">
                {products
                  .filter((p) => p.featured)
                  .slice(0, 4)
                  .map(card)}
              </div>
              <div className="catalog-note">
                Precios e inventario ficticios. Imágenes generadas por IA para una demostración de
                diseño web.
              </div>
            </section>
            <div className="promo-banner">
              <div>
                <span className="eyebrow">PRUEBA LA EXPERIENCIA COMPLETA</span>
                <h2>
                  Tu setup. <em>Tu siguiente nivel.</em>
                </h2>
                <p>
                  Aplica <strong>NFORCE10</strong> en el carrito y descubre el checkout interactivo.
                </p>
              </div>
              <button className="button primary" onClick={() => browse()}>
                Explorar productos <ArrowRight size={18} />
              </button>
            </div>
            <Story onBrowse={browse} />
            <Contact compact />
          </>
        )}
        {(route === 'catalog' || route === 'offers') && (
          <section className="section catalog-page">
            <span className="eyebrow">HARDWARE PARA TU SIGUIENTE NIVEL</span>
            <h1>
              {route === 'offers' ? (
                'Ofertas de otro nivel.'
              ) : (
                <>
                  Todo para <em>tu setup.</em>
                </>
              )}
            </h1>
            <p className="muted">Explora el catálogo ficticio. Ningún producto está a la venta.</p>
            <div className="catalog-toolbar">
              <label className="search">
                <Search size={20} />
                <input
                  id="search"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Buscar nombre, modelo o especificación"
                />
              </label>
              <select
                aria-label="Ordenar productos"
                value={sort}
                onChange={(e) => setSort(e.target.value)}
              >
                <option value="featured">Destacados</option>
                <option value="low">Menor precio</option>
                <option value="high">Mayor precio</option>
              </select>
            </div>
            <div className="catalog-layout">
              <aside className="filters">
                <h3>
                  <SlidersHorizontal size={17} /> Categorías
                </h3>
                <button
                  className={!category ? 'selected' : ''}
                  onClick={() => {
                    setCategory('');
                    setFilters(emptyFilters);
                  }}
                >
                  Todos los productos <span>{products.length}</span>
                </button>
                {categories.map((c) => (
                  <button
                    key={c.id}
                    className={category === c.id ? 'selected' : ''}
                    onClick={() => {
                      setCategory(c.id);
                      setFilters(emptyFilters);
                    }}
                  >
                    {c.name}
                    <span>{products.filter((p) => p.category === c.id).length}</span>
                  </button>
                ))}
                <Facets
                  products={products.filter((p) => !category || p.category === category)}
                  filters={filters}
                  change={setFilters}
                />
              </aside>
              <div>
                <p className="results-count">
                  {visible.filter((p) => route !== 'offers' || p.previousPrice).length} productos ·
                  Imágenes generadas por IA
                </p>
                <div className="product-grid catalog-products">
                  {visible.filter((p) => route !== 'offers' || p.previousPrice).map(card)}
                </div>
                {!visible.length && (
                  <Empty
                    title="No encontramos productos"
                    action="Limpiar búsqueda"
                    onClick={() => {
                      setQuery('');
                      setCategory('');
                      setFilters(emptyFilters);
                    }}
                  />
                )}
              </div>
            </div>
          </section>
        )}
        {route === 'cart' && (
          <section className="section narrow">
            <span className="eyebrow">UN PASO MÁS CERCA</span>
            <h1>
              Tu carrito<span className="green">.</span>
            </h1>
            {!cart.length ? (
              <Empty
                title="Tu próximo setup te espera"
                action="Explorar catálogo"
                onClick={() => browse()}
              />
            ) : (
              <>
                <div className="cart-lines">
                  {cart.map((line) => {
                    const product = products.find((p) => p.id === line.id);
                    if (!product) return null;
                    return (
                      <article className="cart-line" key={line.id}>
                        <div className="cart-art">
                          <img src={product.image} alt="" />
                        </div>
                        <div>
                          <h3>{product.name}</h3>
                          <small>Producto ficticio · {product.stock} disponibles en la demo</small>
                          <strong>{money(product.price)}</strong>
                        </div>
                        <div className="quantity">
                          <button
                            aria-label="Reducir cantidad"
                            onClick={() =>
                              setCart(
                                cart.map((i) =>
                                  i.id === line.id
                                    ? { ...i, quantity: Math.max(1, i.quantity - 1) }
                                    : i,
                                ),
                              )
                            }
                          >
                            <Minus size={14} />
                          </button>
                          {line.quantity}
                          <button
                            aria-label="Aumentar cantidad"
                            disabled={line.quantity >= Math.min(10, product.stock)}
                            onClick={() =>
                              setCart(
                                cart.map((i) =>
                                  i.id === line.id ? { ...i, quantity: i.quantity + 1 } : i,
                                ),
                              )
                            }
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                        <button
                          className="icon-button"
                          aria-label={`Eliminar ${product.name}`}
                          onClick={() => setCart(cart.filter((i) => i.id !== line.id))}
                        >
                          <Trash2 size={18} />
                        </button>
                      </article>
                    );
                  })}
                </div>
                <CartSummary
                  products={products}
                  cart={cart}
                  coupon={coupon}
                  setCoupon={setCoupon}
                />
                <a className="button primary checkout-link" href="#checkout">
                  Probar checkout <ArrowRight size={18} />
                </a>
              </>
            )}
          </section>
        )}
        {route === 'checkout' && (
          <Checkout
            products={products}
            cart={cart}
            coupon={coupon}
            done={(order) => {
              setOrders((current) => [order, ...current]);
              setProducts((current) =>
                current.map((p) => ({
                  ...p,
                  stock: p.stock - (order.items.find((i) => i.id === p.id)?.quantity || 0),
                })),
              );
              setCart([]);
              setCoupon('');
              location.hash = 'orders';
              setNotice('Pedido de demostración registrado. No se realizó ningún cobro.');
            }}
          />
        )}
        {route === 'orders' && (
          <section className="section narrow">
            <span className="eyebrow">TU EXPERIENCIA, PASO A PASO</span>
            <h1>Pedidos de prueba.</h1>
            <p className="muted">
              Solo se guardan en este navegador. No hay compras, pagos ni envíos reales.
            </p>
            {!orders.length ? (
              <Empty
                title="Todavía no tienes pedidos de prueba"
                action="Explorar catálogo"
                onClick={() => browse()}
              />
            ) : (
              orders.map((order) => (
                <article className="order-card" key={order.id}>
                  <div className="section-heading">
                    <div>
                      <small>{order.id}</small>
                      <h3>{statusLabels[order.status]}</h3>
                    </div>
                    <strong>{money(order.total)}</strong>
                  </div>
                  <p>
                    {new Date(order.created).toLocaleString('es-MX')} · {order.customer}
                  </p>
                  {order.items.map((item) => (
                    <p key={item.id}>
                      {item.quantity} × {item.name}
                      <span>{money(item.price * item.quantity)}</span>
                    </p>
                  ))}
                  <div className="order-progress">
                    {['confirmed', 'preparing', 'shipped', 'delivered'].map((status, index) => (
                      <span
                        key={status}
                        className={
                          ['confirmed', 'preparing', 'shipped', 'delivered'].indexOf(
                            order.status,
                          ) >= index
                            ? 'complete'
                            : ''
                        }
                      >
                        <i>{index + 1}</i>
                        {statusLabels[status]}
                      </span>
                    ))}
                  </div>
                </article>
              ))
            )}
            {orders.length > 0 && (
              <a className="button secondary" href="#admin">
                Probar gestión de pedidos <ArrowRight size={17} />
              </a>
            )}
          </section>
        )}
        {route === 'admin' && (
          <Dashboard
            products={products}
            setProducts={setProducts}
            orders={orders}
            setOrders={setOrders}
            reset={reset}
          />
        )}
        {route === 'contact' && <Contact />}
        {['faq', 'terms', 'privacy', 'cookies'].includes(route) && <Info route={route} />}
        {![
          'home',
          'catalog',
          'offers',
          'cart',
          'checkout',
          'orders',
          'admin',
          'contact',
          'faq',
          'terms',
          'privacy',
          'cookies',
          'compare',
        ].includes(route) && (
          <Empty
            title="Esta sección no existe"
            action="Volver al inicio"
            onClick={() => (location.hash = 'home')}
          />
        )}
      </main>
      <footer>
        <div className="footer-top">
          <div>
            <span className="eyebrow">EL SIGUIENTE NIVEL ES TUYO</span>
            <h2>
              ELEVA TU <em>SETUP.</em>
            </h2>
            <a href="#catalog" className="text-link">
              Explora el catálogo <ArrowUpRight />
            </a>
          </div>
          <Logo />
        </div>
        <div className="footer-links">
          <span>Concepto ecommerce · NFORCE Technologies</span>
          <a href="#contact">Contactar con NFORCE</a>
          <a href="#faq">Acerca de la demo</a>
          <a href="#orders">Pedidos de prueba</a>
          <a href="#admin">Panel demo</a>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} BYTEDMEX · Diseño de muestra por{' '}
            <a href={NFORCE.website} target="_blank" rel="noreferrer">
              NFORCE ↗
            </a>
          </span>
          <div>
            <a href="#terms">Aviso de demostración</a>
            <a href="#privacy">Privacidad</a>
            <a href="#cookies">Almacenamiento</a>
          </div>
        </div>
      </footer>
      <a
        className="nforce-floating"
        href={contactUrl()}
        target="_blank"
        rel="noreferrer"
        aria-label="Contactar a NFORCE por WhatsApp"
      >
        <MessageCircle size={22} />
        <span>
          ¿Una web así para ti?<strong>Hablemos con NFORCE ↗</strong>
        </span>
      </a>
      {!!compare.length && (
        <div className="compare-bar">
          <span>
            <GitCompareArrows size={18} />
            {compare.length} para comparar
          </span>
          <button onClick={() => (location.hash = 'compare')}>
            Comparar <ArrowRight size={16} />
          </button>
          <button aria-label="Vaciar comparador" onClick={() => setCompare([])}>
            <X size={18} />
          </button>
        </div>
      )}
      {route === 'compare' && (
        <Modal title="Comparador de productos" close={() => (location.hash = 'catalog')}>
          <div className="comparison">
            {compare
              .map((id) => products.find((p) => p.id === id))
              .filter((p): p is Product => !!p)
              .map((p) => (
                <article key={p.id}>
                  <img className="compare-image" src={p.image} alt={p.name} />
                  <h3>{p.name}</h3>
                  <strong>{money(p.price)}</strong>
                  {Object.entries(p.specs).map(([key, value]) => (
                    <p key={key}>
                      <small>{key}</small>
                      {value}
                    </p>
                  ))}
                  <button className="button primary" disabled={!p.stock} onClick={() => add(p)}>
                    Agregar
                  </button>
                </article>
              ))}
          </div>
          {!compare.length && <p>Selecciona hasta tres productos del catálogo para comparar.</p>}
        </Modal>
      )}
      {selected && (
        <Modal title={selected.name} close={() => setSelected(null)}>
          <div className="product-detail">
            <div className="detail-art">
              <img src={selected.image} alt={`Imagen generada por IA de ${selected.name}`} />
            </div>
            <div>
              <span className="demo-label">PRODUCTO CONCEPTUAL · IMAGEN IA</span>
              <h2>{selected.name}</h2>
              <p>{selected.description}</p>
              <strong className="detail-price">
                {money(selected.price)} <small>MXN ficticios</small>
              </strong>
              <p className="stock">
                {selected.stock
                  ? `● ${selected.stock} disponibles en inventario demo`
                  : 'Agotado en la demo'}
              </p>
              <button
                className="button primary"
                disabled={!selected.stock}
                onClick={() => add(selected)}
              >
                Agregar a carrito <Plus size={18} />
              </button>
              <dl>
                {Object.entries(selected.specs).map(([key, value]) => (
                  <div key={key}>
                    <dt>{key}</dt>
                    <dd>{value}</dd>
                  </div>
                ))}
              </dl>
              <small className="muted">
                Especificaciones ficticias. No se realiza ninguna venta.
              </small>
            </div>
          </div>
        </Modal>
      )}
      <AnimatePresence>
        {notice && (
          <motion.div
            role="status"
            className="toast"
            initial={{ y: 25, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <Check size={18} />
            {notice}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
