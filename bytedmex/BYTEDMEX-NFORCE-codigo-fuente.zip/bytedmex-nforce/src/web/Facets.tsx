import type { Product } from './types';
import { useEffect, useState } from 'react';
import { SlidersHorizontal } from 'lucide-react';
export type Filters = {
  brand: string;
  subcategory: string;
  minimum: string;
  maximum: string;
  specs: Record<string, string>;
};
export const emptyFilters: Filters = {
  brand: '',
  subcategory: '',
  minimum: '',
  maximum: '',
  specs: {},
};
export function matchesFilters(product: Product, filters: Filters) {
  return (
    (!filters.brand || product.brand === filters.brand) &&
    (!filters.subcategory || product.subcategory === filters.subcategory) &&
    (!filters.minimum || product.price >= Number(filters.minimum) * 100) &&
    (!filters.maximum || product.price <= Number(filters.maximum) * 100) &&
    Object.entries(filters.specs).every(([key, value]) => !value || product.specs[key] === value)
  );
}
export function Facets({
  products,
  filters,
  change,
}: {
  products: Product[];
  filters: Filters;
  change: (value: Filters) => void;
}) {
  const [expanded, setExpanded] = useState(() => !matchMedia('(max-width:760px)').matches);
  useEffect(() => {
    const media = matchMedia('(max-width:760px)');
    const update = () => setExpanded(!media.matches);
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  const scoped = products.filter(
    (product) => !filters.subcategory || product.subcategory === filters.subcategory,
  );
  const showSpecifications =
    Boolean(filters.subcategory) ||
    new Set(products.map((p) => p.subcategory)).size === 1 ||
    (new Set(products.map((p) => p.category)).size === 1 &&
      products.every((p) => p.category === 'monitors'));
  const keys = showSpecifications
      ? [...new Set(scoped.flatMap((p) => Object.keys(p.specs)))].slice(0, 12)
      : [],
    brands = [...new Set(products.map((p) => p.brand))],
    subcategories = [...new Set(products.map((p) => p.subcategory).filter(Boolean))];
  return (
    <details
      className="facet-disclosure"
      open={expanded}
      onToggle={(e) => setExpanded(e.currentTarget.open)}
    >
      <summary>
        Filtros avanzados <SlidersHorizontal size={16} />
      </summary>
      <div className="facet-controls">
        <label>
          Marca
          <select
            value={filters.brand}
            onChange={(e) => change({ ...filters, brand: e.target.value })}
          >
            <option value="">Todas</option>
            {brands.map((brand) => (
              <option key={brand}>{brand}</option>
            ))}
          </select>
        </label>
        {subcategories.length > 0 && (
          <label>
            Subcategoría
            <select
              value={filters.subcategory}
              onChange={(e) => change({ ...filters, subcategory: e.target.value, specs: {} })}
            >
              <option value="">Todas</option>
              {subcategories.map((name) => (
                <option key={name}>{name}</option>
              ))}
            </select>
          </label>
        )}
        <div className="price-range">
          <label>
            Precio mínimo
            <input
              type="number"
              min="0"
              value={filters.minimum}
              onChange={(e) => change({ ...filters, minimum: e.target.value })}
              placeholder="MXN"
            />
          </label>
          <label>
            Precio máximo
            <input
              type="number"
              min="0"
              value={filters.maximum}
              onChange={(e) => change({ ...filters, maximum: e.target.value })}
              placeholder="MXN"
            />
          </label>
        </div>
        {keys.map((key) => (
          <label key={key}>
            {key}
            <select
              value={filters.specs[key] || ''}
              onChange={(e) =>
                change({ ...filters, specs: { ...filters.specs, [key]: e.target.value } })
              }
            >
              <option value="">Todas las opciones</option>
              {[...new Set(scoped.map((p) => p.specs[key]).filter(Boolean))].map((value) => (
                <option key={value}>{value}</option>
              ))}
            </select>
          </label>
        ))}
        <button className="text-link" onClick={() => change(emptyFilters)}>
          Limpiar filtros
        </button>
      </div>
    </details>
  );
}
