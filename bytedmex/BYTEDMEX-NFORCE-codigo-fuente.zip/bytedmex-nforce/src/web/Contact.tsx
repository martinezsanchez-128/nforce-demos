import { useState } from 'react';
import { MessageCircle, ArrowUpRight, Mail, ExternalLink } from 'lucide-react';
import { NFORCE, contactUrl } from './catalog';
export function Contact({ compact = false }: { compact?: boolean }) {
  const [project, setProject] = useState('Una tienda online para mi negocio');
  return (
    <section className={compact ? 'nforce-contact compact' : 'nforce-contact'}>
      <div className="contact-intro">
        <a className="nforce-wordmark" href={NFORCE.website} target="_blank" rel="noreferrer">
          NFORCE<span>TECHNOLOGIES</span>
        </a>
        <span className="eyebrow">DISEÑAMOS TU SIGUIENTE PASO</span>
        <h1>
          ¿Una tienda
          <br />
          como <em>esta?</em>
        </h1>
        <p>
          Este es un concepto de lo que podemos crear para tu negocio. Hablemos de tu proyecto y
          diseñemos una experiencia a tu medida.
        </p>
        <div className="contact-badges">
          <span>Diseño web</span>
          <span>Ecommerce</span>
          <span>Automatización e IA</span>
        </div>
      </div>
      <div className="contact-card">
        <span className="eyebrow">HABLEMOS DE TU PROYECTO</span>
        <h2>
          De la idea
          <br />a tu próxima <em>web.</em>
        </h2>
        <label>
          ¿Qué te gustaría crear?
          <textarea
            value={project}
            onChange={(e) => setProject(e.target.value)}
            maxLength={1000}
            rows={3}
          />
        </label>
        <a
          className="button primary"
          href={contactUrl(`Hola NFORCE, vi la demostración BYTEDMEX. Me interesa: ${project}`)}
          target="_blank"
          rel="noreferrer"
        >
          <MessageCircle size={19} /> Cotizar por WhatsApp <ArrowUpRight size={18} />
        </a>
        <div className="contact-methods">
          <a href={contactUrl()} target="_blank" rel="noreferrer">
            <MessageCircle size={18} />
            <div>
              <small>WhatsApp</small>
              {NFORCE.phone}
            </div>
          </a>
          <a href={`mailto:${NFORCE.email}?subject=Proyecto%20web%20desde%20BYTEDMEX`}>
            <Mail size={18} />
            <div>
              <small>Correo</small>
              {NFORCE.email}
            </div>
          </a>
          <a href={NFORCE.website} target="_blank" rel="noreferrer">
            <ExternalLink size={18} />
            <div>
              <small>Sitio oficial</small>nforcetechnologies.com.mx
            </div>
          </a>
        </div>
        <p className="contact-disclaimer">
          Los botones de contacto abren canales reales de NFORCE. Los productos de esta tienda son
          ficticios.
        </p>
      </div>
    </section>
  );
}
