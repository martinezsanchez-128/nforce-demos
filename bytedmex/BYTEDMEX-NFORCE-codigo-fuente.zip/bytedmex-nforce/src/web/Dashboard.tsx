import { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  RotateCcw,
  ArrowRight,
  ArrowUpRight,
} from 'lucide-react';
import { money, statusLabels, type Product, type DemoOrder } from './types';
import { contactUrl } from './catalog';
import { Modal } from './Primitives';
export function Dashboard({
  products,
  setProducts,
  orders,
  setOrders,
  reset,
}: {
  products: Product[];
  setProducts: (products: Product[]) => void;
  orders: DemoOrder[];
  setOrders: (orders: DemoOrder[]) => void;
  reset: () => void;
}) {
  const [tab, setTab] = useState('overview'),
    [editing, setEditing] = useState<Product | null>(null),
    [search, setSearch] = useState('');
  const metrics = [
    [
      'Ventas simuladas',
      money(orders.filter((o) => o.status !== 'cancelled').reduce((sum, o) => sum + o.total, 0)),
    ],
    ['Pedidos de prueba', String(orders.length)],
    ['Productos', String(products.length)],
    ['Unidades ficticias', String(products.reduce((sum, p) => sum + p.stock, 0))],
  ];
  function next(order: DemoOrder) {
    const stages: DemoOrder['status'][] = ['confirmed', 'preparing', 'shipped', 'delivered'];
    const status = stages[Math.min(stages.indexOf(order.status) + 1, 3)];
    setOrders(orders.map((o) => (o.id === order.id ? { ...o, status } : o)));
  }
  return (
    <div className="admin-layout">
      <aside className="admin-sidebar">
        <span className="eyebrow">DEMO CONTROL CENTER</span>
        <h2>Tu tienda, al día.</h2>
        {[
          ['overview', 'Resumen', <LayoutDashboard size={18} />],
          ['products', 'Inventario ficticio', <Package size={18} />],
          ['orders', 'Pedidos de prueba', <ShoppingBag size={18} />],
        ].map(([id, label, icon]) => (
          <button
            key={String(id)}
            className={tab === id ? 'selected' : ''}
            onClick={() => setTab(String(id))}
          >
            {icon}
            {label}
          </button>
        ))}
        <a className="text-link" href="#contact">
          Quiero un panel así ↗
        </a>
      </aside>
      <section className="admin-content">
        <div className="section-heading">
          <div>
            <span className="eyebrow">BYTEDMEX / PANEL DE DEMOSTRACIÓN</span>
            <h1>
              {tab === 'products'
                ? 'Gestiona tu inventario.'
                : tab === 'orders'
                  ? 'Cada pedido, a la vista.'
                  : 'Todo bajo control.'}
            </h1>
          </div>
          <button className="button secondary" onClick={reset}>
            <RotateCcw size={16} /> Restablecer demo
          </button>
        </div>
        <p className="alert">
          Panel abierto de demostración. Los cambios solo se guardan en este navegador; no existe
          acceso a una tienda real.
        </p>
        {tab === 'overview' && (
          <>
            <div className="metric-grid">
              {metrics.map(([label, value]) => (
                <div className="metric" key={label}>
                  <small>{label}</small>
                  <strong>{value}</strong>
                </div>
              ))}
            </div>
            <div className="admin-panel">
              <h3>Una experiencia completa, sin operaciones reales.</h3>
              <p>
                Agrega productos al carrito, aplica cupones, simula una compra y cambia el estado
                del pedido desde este panel.
              </p>
              <p className="muted">
                Inventario, precios, pedidos y cifras son ficticios. Esta web estática funciona
                directamente en GitHub Pages.
              </p>
              <a
                className="text-link"
                href={contactUrl(
                  'Hola NFORCE, vi el panel de BYTEDMEX y quiero un sistema para mi negocio.',
                )}
                target="_blank"
                rel="noreferrer"
              >
                Solicitar un desarrollo a medida <ArrowUpRight size={16} />
              </a>
            </div>
            <div className="admin-panel">
              <h3>Cupones disponibles</h3>
              <p>NFORCE10 · 10% de descuento ficticio.</p>
              <p>SETUP500 · $500 ficticios en compras de muestra desde $5,000.</p>
            </div>
          </>
        )}
        {tab === 'products' && (
          <>
            <label className="admin-search">
              Buscar producto
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Nombre o SKU"
              />
            </label>
            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Producto</th>
                    <th>Precio ficticio</th>
                    <th>Stock demo</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {products
                    .filter((p) =>
                      `${p.name} ${p.sku}`.toLowerCase().includes(search.toLowerCase()),
                    )
                    .map((p) => (
                      <tr key={p.id}>
                        <td>
                          <div className="admin-product">
                            <img src={p.image} alt="" />
                            <div>
                              {p.name}
                              <small>{p.sku}</small>
                            </div>
                          </div>
                        </td>
                        <td>{money(p.price)}</td>
                        <td>
                          <span
                            className={p.stock ? 'inventory-pill' : 'inventory-pill empty-stock'}
                          >
                            {p.stock} unidades
                          </span>
                        </td>
                        <td>
                          <button onClick={() => setEditing(p)}>Editar</button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </>
        )}
        {tab === 'orders' && (
          <>
            {!orders.length ? (
              <div className="empty">
                <Package size={36} />
                <h3>Aún no hay pedidos ficticios</h3>
                <a className="button primary" href="#catalog">
                  Probar la tienda
                </a>
              </div>
            ) : (
              orders.map((order) => (
                <article className="order-card" key={order.id}>
                  <div className="section-heading">
                    <h3>{order.id}</h3>
                    <strong>{money(order.total)}</strong>
                  </div>
                  <p>
                    {statusLabels[order.status]} · {order.customer}
                  </p>
                  {order.items.map((item) => (
                    <p key={item.id}>
                      {item.quantity} × {item.name}
                    </p>
                  ))}
                  <div className="admin-order-actions">
                    {!['delivered', 'cancelled'].includes(order.status) && (
                      <button className="button primary" onClick={() => next(order)}>
                        Avanzar estado de prueba <ArrowRight size={16} />
                      </button>
                    )}
                    {['confirmed', 'preparing'].includes(order.status) && (
                      <button
                        className="button secondary"
                        onClick={() => {
                          setOrders(
                            orders.map((o) =>
                              o.id === order.id ? { ...o, status: 'cancelled' } : o,
                            ),
                          );
                          setProducts(
                            products.map((p) => ({
                              ...p,
                              stock:
                                p.stock + (order.items.find((i) => i.id === p.id)?.quantity || 0),
                            })),
                          );
                        }}
                      >
                        Cancelar y reponer stock demo
                      </button>
                    )}
                  </div>
                </article>
              ))
            )}
          </>
        )}
        {editing && (
          <Modal title={`Editar ${editing.name}`} close={() => setEditing(null)}>
            <form
              className="inventory-editor"
              onSubmit={(e) => {
                e.preventDefault();
                const fields = Object.fromEntries(new FormData(e.currentTarget));
                const price = Math.round(Number(fields.price) * 100),
                  stock = Number(fields.stock);
                if (
                  !Number.isSafeInteger(price) ||
                  price < 100 ||
                  !Number.isInteger(stock) ||
                  stock < 0 ||
                  stock > 999
                )
                  return;
                setProducts(
                  products.map((p) =>
                    p.id === editing.id
                      ? {
                          ...p,
                          name: String(fields.name).slice(0, 100),
                          price,
                          stock,
                          featured: fields.featured === 'on',
                        }
                      : p,
                  ),
                );
                setEditing(null);
              }}
            >
              <img src={editing.image} alt={editing.name} />
              <div>
                <span className="eyebrow">INVENTARIO FICTICIO</span>
                <h2>Editar producto</h2>
                <label>
                  Nombre de muestra
                  <input name="name" defaultValue={editing.name} required maxLength={100} />
                </label>
                <label>
                  Precio ficticio MXN
                  <input
                    name="price"
                    type="number"
                    defaultValue={editing.price / 100}
                    min="1"
                    max="1000000"
                    step=".01"
                    required
                  />
                </label>
                <label>
                  Stock de demostración
                  <input
                    name="stock"
                    type="number"
                    defaultValue={editing.stock}
                    min="0"
                    max="999"
                    step="1"
                    required
                  />
                </label>
                <label className="checkbox">
                  <input name="featured" type="checkbox" defaultChecked={editing.featured} />{' '}
                  Mostrar en destacados
                </label>
                <button className="button primary">Guardar en este navegador</button>
              </div>
            </form>
          </Modal>
        )}
      </section>
    </div>
  );
}
