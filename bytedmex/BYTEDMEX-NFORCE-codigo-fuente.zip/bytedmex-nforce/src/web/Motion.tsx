import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { SplitText } from 'gsap/SplitText';
import { useGSAP } from '@gsap/react';
import Lenis from 'lenis';
import { ArrowRight, ArrowUpRight, Play, ChevronDown } from 'lucide-react';
gsap.registerPlugin(ScrollTrigger, SplitText, useGSAP);
const LenisContext = createContext<Lenis | null>(null);
export const useLenis = () => useContext(LenisContext);
export const HERO_VIDEO =
  'https://d8j0ntlcm91z4.cloudfront.net/user_3Bd1EO6EIHxSqCgleKKy9qZ3l1v/hf_20260715_151356_acd1382f-aab3-4105-b133-ade208ff9def.mp4';
const assets = `${import.meta.env.BASE_URL}images/`;
export function SmoothScrollProvider({ children }: { children: ReactNode }) {
  const [lenis, setLenis] = useState<Lenis | null>(null);
  useEffect(() => {
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    const instance = new Lenis({ anchors: false });
    setLenis(instance);
    instance.on('scroll', ScrollTrigger.update);
    const tick = (time: number) => instance.raf(time * 1000);
    gsap.ticker.add(tick);
    gsap.ticker.lagSmoothing(0);
    return () => {
      gsap.ticker.remove(tick);
      instance.destroy();
    };
  }, []);
  return <LenisContext.Provider value={lenis}>{children}</LenisContext.Provider>;
}
function Preloader({ done }: { done: () => void }) {
  const wrapper = useRef<HTMLDivElement>(null),
    number = useRef<HTMLSpanElement>(null),
    called = useRef(false),
    doneRef = useRef(done);
  doneRef.current = done;
  const lenis = useLenis();
  useEffect(() => {
    lenis?.stop();
    return () => lenis?.start();
  }, [lenis]);
  useGSAP(() => {
    const call = () => {
      if (!called.current) {
        called.current = true;
        doneRef.current();
      }
    };
    if (matchMedia('(prefers-reduced-motion: reduce)').matches) {
      call();
      return;
    }
    const old = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const counter = { value: 0 };
    const timeline = gsap
      .timeline({ onComplete: call })
      .to(counter, {
        value: 100,
        duration: 1.6,
        ease: 'power2.inOut',
        onUpdate: () => {
          if (number.current) number.current.textContent = String(Math.round(counter.value));
        },
      })
      .to(
        wrapper.current,
        { clipPath: 'polygon(0 0,100% 0,100% 0%,0 0%)', duration: 1, ease: 'expo.out' },
        '+=0.1',
      );
    return () => {
      timeline.kill();
      document.body.style.overflow = old;
    };
  }, []);
  return (
    <div ref={wrapper} className="preloader" aria-hidden="true">
      <span>
        BYTE<b>DM</b>EX
      </span>
      <span ref={number} className="loading-number">
        0
      </span>
      <small>ELEVA TU SETUP</small>
    </div>
  );
}
export function Hero({ onBrowse }: { onBrowse: (id?: string) => void }) {
  const wrapper = useRef<HTMLElement>(null),
    video = useRef<HTMLVideoElement>(null),
    title = useRef<HTMLHeadingElement>(null),
    reveal = useRef<() => void>(() => {});
  const [introDone, setIntroDone] = useState(false),
    [failed, setFailed] = useState(false);
  useGSAP(
    () => {
      gsap.registerPlugin(ScrollTrigger, SplitText);
      const element = video.current!;
      const mm = gsap.matchMedia();
      mm.add(
        {
          reduced: '(prefers-reduced-motion: reduce)',
          full: '(prefers-reduced-motion: no-preference)',
        },
        (context) => {
          if (context.conditions?.reduced) {
            gsap.set('.hero-reveal', { autoAlpha: 1, y: 0 });
            return;
          }
          const split = SplitText.create(title.current!, {
            type: 'lines',
            mask: 'lines',
            autoSplit: true,
          });
          gsap.set(element, { scale: 1.15 });
          gsap.set(split.lines, { yPercent: 100, rotate: 3 });
          gsap.set('.hero-reveal', { autoAlpha: 0, y: 16 });
          reveal.current = () => {
            gsap.to(element, { scale: 1, duration: 1.4, ease: 'expo.out' });
            gsap.to(split.lines, {
              yPercent: 0,
              rotate: 0,
              duration: 1.2,
              ease: 'expo.out',
              stagger: 0.06,
              delay: 0.3,
            });
            gsap.to('.hero-reveal', {
              autoAlpha: 1,
              y: 0,
              duration: 1,
              ease: 'expo.out',
              stagger: 0.1,
              delay: 0.5,
            });
          };
          let duration = 0,
            target = 0,
            pending = false;
          const seek = () => {
            if (element.seeking) {
              pending = true;
              return;
            }
            try {
              element.currentTime = Math.min(target, Math.max(0, duration - 0.04));
            } catch {
              /* Metadata may become unavailable after a network error. */
            }
          };
          const seeked = () => {
            if (pending) {
              pending = false;
              seek();
            }
          };
          const metadata = () => {
            duration = Number.isFinite(element.duration) ? element.duration : 0;
            element.currentTime = 0;
            ScrollTrigger.refresh();
          };
          element.addEventListener('loadedmetadata', metadata);
          element.addEventListener('seeked', seeked);
          if (element.readyState >= 1) metadata();
          const trigger = ScrollTrigger.create({
            trigger: wrapper.current,
            start: 'top top',
            end: '+=300%',
            pin: true,
            scrub: 1,
            anticipatePin: 1,
            onUpdate: (self) => {
              if (!duration) return;
              target = self.progress * duration;
              seek();
            },
          });
          return () => {
            trigger.kill();
            element.removeEventListener('loadedmetadata', metadata);
            element.removeEventListener('seeked', seeked);
            split.revert();
          };
        },
      );
      return () => mm.revert();
    },
    { scope: wrapper },
  );
  useEffect(() => {
    if (introDone) reveal.current();
  }, [introDone]);
  return (
    <>
      {!introDone && <Preloader done={() => setIntroDone(true)} />}
      <section className="hero" ref={wrapper} data-theme="dark">
        <div className="hero-grid" aria-hidden="true" />
        <div className="hero-media">
          <div className="hero-video-inner">
            <video
              ref={video}
              src={HERO_VIDEO}
              poster={`${assets}keyboard.webp`}
              muted
              playsInline
              preload="auto"
              onError={() => setFailed(true)}
              aria-label="Video de periféricos gaming, controlado al desplazarte"
            />
            <div className="video-shade" />
          </div>
        </div>
        <div className="hero-content">
          <div className="hero-reveal hero-kicker">
            <span className="live-dot" /> HARDWARE SIN LÍMITES <span className="kicker-line" />
          </div>
          <h1 ref={title}>
            ELEVA
            <br />
            TU <span>SETUP.</span>
          </h1>
          <p className="hero-reveal hero-subtitle">
            Más potencia. Más precisión. Más tú.
            <br />
            Tecnología para llevar cada partida al siguiente nivel.
          </p>
          <div className="hero-reveal hero-ctas">
            <button className="button primary" onClick={() => onBrowse('components')}>
              Explorar componentes <ArrowUpRight size={19} />
            </button>
            <button className="button hero-secondary" onClick={() => onBrowse('peripherals')}>
              Ver periféricos <ArrowRight size={17} />
            </button>
          </div>
          <div className="hero-reveal hero-caption">
            <span className="tiny-cross">+</span>
            <span>
              PARA QUIENES NUNCA
              <br />
              SE CONFORMAN.
            </span>
          </div>
        </div>
        <div className="hero-reveal hero-bottom">
          <span>
            <Play size={12} />{' '}
            {failed ? 'VIDEO NO DISPONIBLE · EXPLORA EL CATÁLOGO' : 'SCROLL PARA EXPLORAR'}
          </span>
          <span>01 / BYTEDMEX COLLECTION</span>
          <ChevronDown size={19} />
        </div>
        <span className="hero-side-label">DESIGNED FOR YOUR NEXT LEVEL — MX</span>
      </section>
    </>
  );
}
const themes = {
  light: { bg: '#fafaf8', text: '#101114' },
  dark: { bg: '#101114', text: '#ffffff' },
};
function useThemeSwap(root: React.RefObject<HTMLElement | null>) {
  useGSAP(
    () => {
      gsap.registerPlugin(ScrollTrigger);
      const triggers = [...(root.current?.querySelectorAll<HTMLElement>('[data-theme]') || [])].map(
        (section) => {
          const apply = () => {
            const theme = themes[section.dataset.theme as keyof typeof themes];
            document.documentElement.style.setProperty('--page-bg', theme.bg);
            document.documentElement.style.setProperty('--page-text', theme.text);
          };
          return ScrollTrigger.create({
            trigger: section,
            start: 'top 55%',
            end: 'bottom 55%',
            onEnter: apply,
            onEnterBack: apply,
          });
        },
      );
      return () => {
        triggers.forEach((t) => t.kill());
        document.documentElement.style.setProperty('--page-bg', '#101114');
        document.documentElement.style.setProperty('--page-text', '#ffffff');
      };
    },
    { scope: root },
  );
}
export function Story({ onBrowse }: { onBrowse: (id?: string) => void }) {
  const root = useRef<HTMLDivElement>(null),
    big = useRef<HTMLElement>(null),
    gallery = useRef<HTMLDivElement>(null),
    footer = useRef<HTMLDivElement>(null);
  useThemeSwap(root);
  useGSAP(
    () => {
      gsap.registerPlugin(ScrollTrigger);
      const mm = gsap.matchMedia();
      mm.add('(prefers-reduced-motion: no-preference)', () => {
        const lines = big.current!.querySelectorAll('h2');
        const progress = big.current!.querySelector('.story-progress i');
        gsap.set(lines, { rotate: -8 });
        gsap.set(progress, { scaleX: 0 });
        ScrollTrigger.create({
          trigger: big.current,
          start: 'top top',
          end: '+=120%',
          pin: true,
          scrub: 1,
          onUpdate: (self) => {
            gsap.set(lines, { rotate: gsap.utils.mapRange(0, 1, -8, 8, self.progress) });
            gsap.set(progress, { scaleX: self.progress });
          },
        });
        const wrappers = gallery.current!.querySelectorAll<HTMLElement>('.stack-wrapper');
        wrappers.forEach((wrapper, i) => {
          const card = wrapper.querySelector('.stack-card'),
            image = wrapper.querySelector('img');
          if (i < wrappers.length - 1) {
            gsap.to(card, {
              rotationZ: (i % 2 ? 1 : -1) * 4,
              scale: 0.7,
              rotationX: 40,
              ease: 'none',
              scrollTrigger: {
                trigger: wrapper,
                start: 'top top',
                end: 'bottom center',
                endTrigger: gallery.current,
                scrub: true,
              },
            });
            gsap.to(card, {
              autoAlpha: 0,
              ease: 'power1.in',
              scrollTrigger: {
                trigger: card,
                start: 'top -80%',
                end: () => `+=${0.2 * innerHeight}`,
                scrub: true,
              },
            });
          }
          gsap.set(image, { scale: 0.3 });
          gsap.to(image, {
            scale: 1,
            ease: 'none',
            scrollTrigger: { trigger: wrapper, start: 'top 80%', end: 'top 30%', scrub: 1 },
          });
        });
        gsap.fromTo(
          footer.current,
          { autoAlpha: 0, y: 40 },
          {
            autoAlpha: 1,
            y: 0,
            duration: 1.1,
            ease: 'expo.out',
            scrollTrigger: { trigger: footer.current, start: 'top 85%' },
          },
        );
      });
      return () => mm.revert();
    },
    { scope: root },
  );
  const groups = [
    {
      name: 'PRECISIÓN.',
      label: 'TECLADOS',
      description: 'Cada pulsación cuenta. Encuentra el teclado que sigue tu ritmo.',
      file: 'keyboard.webp',
    },
    {
      name: 'CONTROL.',
      label: 'MOUSE',
      description: 'El siguiente movimiento es tuyo. Dale a tu setup la precisión que merece.',
      file: 'mouse.webp',
    },
    {
      name: 'INMERSIÓN.',
      label: 'AUDIO',
      description: 'Escucha cada detalle. Entra en la partida con toda tu atención.',
      file: 'headset.webp',
    },
  ];
  return (
    <div className="story" ref={root}>
      <Stats />
      <section ref={big} className="big-text" data-theme="dark">
        <span className="eyebrow">TU FORMA DE JUGAR. TUS REGLAS.</span>
        <h2>SETUP</h2>
        <h2>
          SIN <em>LÍMITES.</em>
        </h2>
        <div className="story-progress">
          <i />
        </div>
      </section>
      <section data-theme="light" className="stack-products">
        <div className="stack-heading">
          <span className="eyebrow">ENCUENTRA TU VENTAJA</span>
          <h2>
            Diseñado para <em>tu siguiente nivel.</em>
          </h2>
        </div>
        <div ref={gallery}>
          {groups.map((group, i) => (
            <div className="stack-wrapper" key={group.label} style={{ zIndex: i + 1 }}>
              <article className="stack-card">
                <div className="stack-inner">
                  <div>
                    <span className="eyebrow">
                      0{i + 1} / {group.label}
                    </span>
                    <h2>{group.name}</h2>
                    <p>{group.description}</p>
                    <button className="button primary" onClick={() => onBrowse('peripherals')}>
                      Explorar {group.label.toLowerCase()} <ArrowUpRight size={19} />
                    </button>
                  </div>
                  <div className="stack-image">
                    <img
                      src={assets + group.file}
                      alt={`${group.label}, imagen conceptual generada por IA`}
                      loading="lazy"
                    />
                  </div>
                </div>
              </article>
            </div>
          ))}
        </div>
      </section>
      <div ref={footer} className="story-ending" data-theme="dark">
        <span className="eyebrow">UN SETUP A TU ALTURA</span>
        <h2>
          Tu próximo nivel
          <br />
          empieza <em>contigo.</em>
        </h2>
        <button className="button primary" onClick={() => onBrowse()}>
          Explorar todo el catálogo <ArrowUpRight size={19} />
        </button>
      </div>
    </div>
  );
}
function Stats() {
  const section = useRef<HTMLElement>(null);
  useGSAP(
    () => {
      gsap.registerPlugin(ScrollTrigger, SplitText);
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const headings = [...section.current!.querySelectorAll('h2')],
        subtitles = [...section.current!.querySelectorAll('p')];
      const hs = headings.map((el) => new SplitText(el, { type: 'chars' })),
        ss = subtitles.map((el) => new SplitText(el, { type: 'words' }));
      gsap.set([...headings, ...hs.flatMap((s) => s.chars)], { yPercent: 100 });
      gsap.set([...subtitles, ...ss.flatMap((s) => s.words)], { yPercent: 100, autoAlpha: 0 });
      let current = -1,
        first = true,
        interval: ReturnType<typeof setInterval> | undefined,
        timeline: gsap.core.Timeline | undefined;
      const timing = {
        headingStagger: 0.15,
        headingDuration: 0.75,
        headingContainerDuration: 1,
        textStagger: 0.05,
        textDuration: 0.6,
        textContainerDuration: 0.8,
        textSlideInDelay: 0.2,
        slideOutDelay: 0.1,
      };
      const change = () => {
        const next = (current + 1) % headings.length;
        const outgoing = current;
        const initial = first;
        const delay = initial
          ? 0
          : timing.slideOutDelay +
            ((hs[outgoing].chars.length * 2) / 3 - 1) * timing.headingStagger;
        const textDelay = delay + timing.textSlideInDelay;
        timeline = gsap.timeline({
          onComplete: () => {
            if (!initial) {
              gsap.set([headings[outgoing], ...hs[outgoing].chars], { yPercent: 100 });
              gsap.set([subtitles[outgoing], ...ss[outgoing].words], {
                yPercent: 100,
                autoAlpha: 0,
              });
            }
            current = next;
            first = false;
          },
        });
        timeline
          .fromTo(
            headings[next],
            { yPercent: 100 },
            { yPercent: 0, ease: 'power2.out', duration: timing.headingContainerDuration },
            delay,
          )
          .fromTo(
            hs[next].chars,
            { yPercent: 100 },
            {
              yPercent: 0,
              ease: 'power2.out',
              duration: timing.headingDuration,
              stagger: timing.headingStagger,
            },
            delay,
          )
          .fromTo(
            subtitles[next],
            { yPercent: 100, autoAlpha: 0 },
            {
              yPercent: 0,
              autoAlpha: 1,
              ease: 'power2.out',
              duration: timing.textContainerDuration,
            },
            textDelay,
          )
          .fromTo(
            ss[next].words,
            { yPercent: 100, autoAlpha: 0 },
            {
              yPercent: 0,
              autoAlpha: 1,
              ease: 'power2.out',
              duration: timing.textDuration,
              stagger: timing.textStagger,
            },
            textDelay,
          );
        if (!initial)
          timeline
            .to(
              headings[outgoing],
              { yPercent: -100, ease: 'power2.in', duration: timing.headingContainerDuration },
              timing.slideOutDelay,
            )
            .to(
              hs[outgoing].chars,
              {
                yPercent: -100,
                ease: 'power2.in',
                duration: timing.headingDuration,
                stagger: -timing.headingStagger,
              },
              timing.slideOutDelay,
            )
            .to(
              subtitles[outgoing],
              {
                yPercent: -100,
                autoAlpha: 0,
                ease: 'power2.in',
                duration: timing.textContainerDuration,
              },
              timing.slideOutDelay,
            )
            .to(
              ss[outgoing].words,
              {
                yPercent: -100,
                autoAlpha: 0,
                ease: 'power2.in',
                duration: timing.textDuration,
                stagger: -timing.textStagger,
              },
              timing.slideOutDelay,
            );
      };
      const trigger = ScrollTrigger.create({
        trigger: section.current,
        start: () => (innerWidth < 768 ? 'top 80%' : 'top 50%'),
        once: true,
        onEnter: () => {
          change();
          interval = setInterval(change, 4000);
        },
      });
      return () => {
        clearInterval(interval);
        timeline?.kill();
        trigger.kill();
        hs.forEach((s) => s.revert());
        ss.forEach((s) => s.revert());
      };
    },
    { scope: section },
  );
  return (
    <section ref={section} className="stats-section" data-theme="dark">
      <div className="stats-slider">
        {[
          ['20', 'PRODUCTOS FICTICIOS PARA EXPLORAR'],
          ['TU SETUP', 'UNA EXPERIENCIA ECOMMERCE INTERACTIVA'],
          ['NFORCE', 'DISEÑO Y DESARROLLO PARA TU NEGOCIO'],
        ].map(([heading, sub], i) => (
          <div key={heading} className={`stat-slide ${i === 0 ? 'first' : ''}`}>
            <div className="stat-mask">
              <h2>{heading}</h2>
            </div>
            <div className="stat-mask">
              <p>{sub}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
