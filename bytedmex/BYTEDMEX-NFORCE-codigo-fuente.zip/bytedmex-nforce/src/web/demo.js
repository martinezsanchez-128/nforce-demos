/** Deterministic browser-only commerce. No network, payments, or real inventory. */
export function calculateCart(products, cart, coupon = '') {
  if (!Array.isArray(cart) || cart.length > 50) throw new Error('Carrito inválido');
  const seen = new Set();
  let subtotal = 0;
  const items = cart.map((line) => {
    const p = products.find((p) => p.id === line.id);
    if (
      !p ||
      seen.has(line.id) ||
      !Number.isInteger(line.quantity) ||
      line.quantity < 1 ||
      line.quantity > Math.min(10, p.stock)
    )
      throw new Error('Actualiza cantidades: el inventario de demostración cambió');
    seen.add(line.id);
    subtotal += p.price * line.quantity;
    return { id: p.id, name: p.name, price: p.price, quantity: line.quantity, image: p.image };
  });
  const code = coupon.trim().toUpperCase();
  if (code && !['NFORCE10', 'SETUP500'].includes(code))
    throw new Error('Cupón no válido. Prueba NFORCE10 o SETUP500.');
  if (code === 'SETUP500' && subtotal < 500000)
    throw new Error('SETUP500 requiere una compra ficticia de $5,000 MXN.');
  const discount =
    code === 'NFORCE10' ? Math.round(subtotal * 0.1) : code === 'SETUP500' ? 50000 : 0;
  const shipping = subtotal === 0 || subtotal - discount >= 500000 ? 0 : 14900;
  return {
    items,
    subtotal,
    discount,
    shipping,
    total: subtotal - discount + shipping,
    coupon: code,
  };
}
export function readLocal(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}
export function writeLocal(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}
