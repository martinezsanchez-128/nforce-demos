import { ArrowUpRight } from 'lucide-react';
export function Info({ route }: { route: string }) {
  const content: Record<string, [string, string[]]> = {
    faq: [
      'Una tienda de muestra. Una idea para tu negocio.',
      [
        'BYTEDMEX es una demostración de diseño y desarrollo web de NFORCE Technologies. Puedes probar catálogo, filtros, comparador, carrito, cupones, checkout y administración.',
        'Todos los productos, marcas de hardware, precios, especificaciones y existencias son ficticios. Las fotografías del catálogo se generaron con IA.',
        'No hay compras, cobros, cuentas reales ni envíos. Los pedidos y cambios se guardan únicamente en tu navegador.',
        '¿Quieres algo similar para tu negocio? Contacta con NFORCE para definir diseño, alcance e integraciones reales.',
      ],
    ],
    terms: [
      'Aviso de demostración.',
      [
        'Esta página forma parte del portafolio de NFORCE Technologies. BYTEDMEX es una marca conceptual utilizada para mostrar un diseño ecommerce.',
        'Los productos no se ofrecen a la venta. Todos los precios, descuentos, existencias y estados de pedido son ilustrativos.',
        'El checkout no procesa pagos ni solicita tarjetas. Usa únicamente datos ficticios.',
        'Los enlaces de WhatsApp, correo y sitio oficial permiten contactar realmente con NFORCE.',
      ],
    ],
    privacy: [
      'Tu privacidad en esta demo.',
      [
        'El catálogo, carrito y pedidos de muestra se guardan mediante localStorage en tu navegador. No se envían a un servidor de BYTEDMEX.',
        'No introduzcas datos personales reales. El checkout viene precargado con un perfil ficticio y no necesita correo, teléfono ni información bancaria.',
        'Al contactar con NFORCE por WhatsApp o correo saldrás de esta demostración y se aplicarán las condiciones del servicio que elijas.',
        'El video original se carga desde CloudFront y las fuentes desde Google Fonts. El alojamiento puede registrar información técnica de acceso según sus propias políticas.',
      ],
    ],
    cookies: [
      'Almacenamiento local.',
      [
        'Esta demo utiliza localStorage para recordar el carrito, los pedidos de prueba y los cambios en el inventario ficticio.',
        'No se crean cookies publicitarias ni se incluyen herramientas de analítica.',
        'Puedes restablecer todos los datos de esta demostración desde el panel demo o borrar el almacenamiento del sitio desde tu navegador.',
      ],
    ],
  };
  const [title, paragraphs] = content[route];
  return (
    <section className="section narrow prose">
      <span className="eyebrow">BYTEDMEX × NFORCE</span>
      <h1>{title}</h1>
      {paragraphs.map((p) => (
        <p key={p}>{p}</p>
      ))}
      <a className="button primary" href="#contact">
        Contactar con NFORCE <ArrowUpRight size={17} />
      </a>
    </section>
  );
}
