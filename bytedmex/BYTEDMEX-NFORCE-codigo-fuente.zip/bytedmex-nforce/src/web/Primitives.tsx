import { useEffect, useRef, type ReactNode } from 'react';
import { Plus, GitCompareArrows, ShoppingBag, ArrowRight, X } from 'lucide-react';
import { useLenis } from './Motion';
import { money, type Product } from './types';
export function ProductCard({
  product: p,
  add,
  select,
  compare,
  compared,
}: {
  product: Product;
  add: (p: Product) => void;
  select: (p: Product) => void;
  compare: () => void;
  compared: boolean;
}) {
  return (
    <article className="product-card">
      <div className="product-visual">
        <span className="product-badge">{p.previousPrice ? 'OFERTA DEMO' : 'CONCEPTO IA'}</span>
        <button
          className={compared ? 'compare-toggle on' : 'compare-toggle'}
          aria-label={`Comparar ${p.name}`}
          aria-pressed={compared}
          onClick={compare}
        >
          <GitCompareArrows size={17} />
        </button>
        <button
          className="product-image-button"
          aria-label={`Ver ${p.name}`}
          onClick={() => select(p)}
        >
          <img src={p.image} alt={p.name} loading="lazy" width="1024" height="1024" />
        </button>
      </div>
      <div className="product-info">
        <span className="product-brand">{p.subcategory.toUpperCase()}</span>
        <button className="product-title" onClick={() => select(p)}>
          {p.name}
        </button>
        <p className="product-spec">{Object.values(p.specs).slice(0, 2).join(' · ')}</p>
        <span className={p.stock ? 'stock' : 'stock sold-out'}>
          {p.stock ? `● ${p.stock} disponibles · Demo` : '● Agotado · Demo'}
        </span>
        <div className="product-price">
          <div>
            {p.previousPrice && <del>{money(p.previousPrice)}</del>}
            <strong>
              {money(p.price)}
              <small> MXN</small>
            </strong>
          </div>
          <button
            disabled={!p.stock}
            aria-label={`Agregar ${p.name} al carrito`}
            onClick={() => add(p)}
          >
            <Plus size={21} />
          </button>
        </div>
      </div>
    </article>
  );
}
export function Empty({
  title,
  action,
  onClick,
}: {
  title: string;
  action: string;
  onClick: () => void;
}) {
  return (
    <div className="empty">
      <ShoppingBag size={42} />
      <h2>{title}</h2>
      <button className="button primary" onClick={onClick}>
        {action}
        <ArrowRight size={17} />
      </button>
    </div>
  );
}
export function Modal({
  title,
  close,
  children,
}: {
  title: string;
  close: () => void;
  children: ReactNode;
}) {
  const dialog = useRef<HTMLDialogElement>(null),
    lenis = useLenis();
  useEffect(() => {
    dialog.current?.showModal();
    lenis?.stop();
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      lenis?.start();
      document.body.style.overflow = previous;
    };
  }, [lenis]);
  return (
    <dialog
      ref={dialog}
      aria-label={title}
      className="modal"
      data-lenis-prevent
      onCancel={(e) => {
        e.preventDefault();
        close();
      }}
    >
      <button autoFocus className="modal-close" aria-label="Cerrar" onClick={close}>
        <X />
      </button>
      {children}
    </dialog>
  );
}
