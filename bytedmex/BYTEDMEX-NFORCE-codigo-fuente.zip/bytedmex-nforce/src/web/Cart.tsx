import { useState, useRef } from 'react';
import { ArrowRight, Check, ArrowUpRight } from 'lucide-react';
import { money, type Product, type CartLine, type DemoOrder } from './types';
import { calculateCart } from './demo.js';
import { Empty } from './Primitives';
import { contactUrl } from './catalog';
export function CartSummary({
  products,
  cart,
  coupon,
  setCoupon,
}: {
  products: Product[];
  cart: CartLine[];
  coupon: string;
  setCoupon: (value: string) => void;
}) {
  const [input, setInput] = useState(coupon),
    [error, setError] = useState('');
  let quote;
  try {
    quote = calculateCart(products, cart, coupon);
  } catch (error) {
    return (
      <p role="alert" className="alert">
        {(error as Error).message}
      </p>
    );
  }
  return (
    <div className="demo-summary">
      <label>
        Cupón de demostración
        <div className="coupon-row">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="NFORCE10"
            maxLength={30}
          />
          <button
            className="button secondary"
            onClick={() => {
              try {
                calculateCart(products, cart, input);
                setCoupon(input);
                setError('');
              } catch (error) {
                setError((error as Error).message);
              }
            }}
          >
            Aplicar
          </button>
        </div>
      </label>
      {error && <p role="alert">{error}</p>}
      <Summary quote={quote} />
      <small>Prueba NFORCE10 (10%) o SETUP500 ($500 en compras ficticias desde $5,000).</small>
    </div>
  );
}
export function Summary({ quote }: { quote: ReturnType<typeof calculateCart> }) {
  return (
    <div className="quote-summary">
      <p>
        <span>Subtotal</span>
        <strong>{money(quote.subtotal)}</strong>
      </p>
      {quote.discount > 0 && (
        <p>
          <span>Descuento · {quote.coupon}</span>
          <strong>−{money(quote.discount)}</strong>
        </p>
      )}
      <p>
        <span>Envío simulado</span>
        <strong>{quote.shipping ? money(quote.shipping) : 'Gratis'}</strong>
      </p>
      <p className="quote-total">
        <span>Total ficticio</span>
        <strong>{money(quote.total)}</strong>
      </p>
      <small>
        Sin cobros. Envío demo gratis desde $5,000 después del descuento; $149 en pedidos menores.
      </small>
    </div>
  );
}
export function Checkout({
  products,
  cart,
  coupon,
  done,
}: {
  products: Product[];
  cart: CartLine[];
  coupon: string;
  done: (order: DemoOrder) => void;
}) {
  const [error, setError] = useState(''),
    [busy, setBusy] = useState(false),
    [completed, setCompleted] = useState(false);
  const submitting = useRef(false);
  let quote;
  try {
    quote = calculateCart(products, cart, coupon);
  } catch (error) {
    return (
      <section className="section narrow">
        <h1>Revisa tu carrito.</h1>
        <p>{(error as Error).message}</p>
        <a className="button primary" href="#cart">
          Volver al carrito
        </a>
      </section>
    );
  }
  if (!cart.length)
    return (
      <Empty
        title="Tu carrito está vacío"
        action="Ver catálogo"
        onClick={() => (location.hash = 'catalog')}
      />
    );
  return (
    <section className="section checkout-page">
      <div>
        <span className="eyebrow">EXPERIENCIA DE COMPRA · DEMO</span>
        <h1>
          Tu setup está
          <br />
          <em>a un paso.</em>
        </h1>
        <p className="alert">
          No es una compra real. Usa los datos ficticios precargados. No solicitamos tarjetas ni
          procesamos pagos.
        </p>
        <form
          className="checkout-form"
          onSubmit={async (e) => {
            e.preventDefault();
            if (submitting.current || completed) return;
            submitting.current = true;
            setBusy(true);
            const data = new FormData(e.currentTarget);
            try {
              const checked = calculateCart(products, cart, coupon);
              await new Promise((resolve) => setTimeout(resolve, 650));
              setCompleted(true);
              done({
                id: `DEMO-${crypto.randomUUID().slice(0, 8).toUpperCase()}`,
                created: new Date().toISOString(),
                status: 'confirmed',
                ...checked,
                customer: String(data.get('name') || 'Alex Demo'),
              });
            } catch (error) {
              setError((error as Error).message);
              submitting.current = false;
              setBusy(false);
            }
          }}
        >
          <h3>01 · Perfil de prueba</h3>
          <div className="form-grid">
            {[
              ['name', 'Nombre ficticio', 'Alex Demo'],
              ['city', 'Ciudad ficticia', 'Ciudad Demo'],
              ['street', 'Dirección ficticia', 'Avenida Ejemplo 123'],
              ['postal', 'Código postal de muestra', '64000'],
            ].map(([name, label, value]) => (
              <label key={name}>
                {label}
                <input
                  name={name}
                  defaultValue={value}
                  required
                  maxLength={100}
                  autoComplete="off"
                />
              </label>
            ))}
          </div>
          <h3>02 · Método de pago ilustrativo</h3>
          <label className="demo-payment">
            <input type="radio" name="payment" defaultChecked /> Simulación de pago · Sin tarjeta ni
            cobro <Check size={18} />
          </label>
          <label className="checkbox">
            <input type="checkbox" required /> Entiendo que esta experiencia es una demostración de
            NFORCE y no realiza una compra.
          </label>
          <button className="button primary" disabled={busy || completed}>
            {busy ? 'Simulando pedido…' : 'Confirmar pedido de prueba'}
            <ArrowRight size={17} />
          </button>
          <p role="alert">{error}</p>
        </form>
      </div>
      <aside>
        <Summary quote={quote} />
        <div className="checkout-promo">
          <span className="eyebrow">ASÍ PODRÍA FUNCIONAR TU NEGOCIO</span>
          <h3>
            Convierte visitas
            <br />
            en <em>oportunidades.</em>
          </h3>
          <a href={contactUrl()} target="_blank" rel="noreferrer" className="text-link">
            Cotiza tu ecommerce con NFORCE <ArrowUpRight size={17} />
          </a>
        </div>
      </aside>
    </section>
  );
}
