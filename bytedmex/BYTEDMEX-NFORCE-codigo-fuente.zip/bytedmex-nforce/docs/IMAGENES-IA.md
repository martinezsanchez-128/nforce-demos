# Inventario visual generado por IA

Se utilizó la herramienta integrada de generación de imágenes. Se generaron doce
imágenes independientes; no se extrajeron fotos de tiendas ni distribuidores.
Los PNG originales se preservaron en la ubicación original de generación y los
archivos del proyecto se codificaron como WebP, sin cambios semánticos.

## Prompt común: primeros ocho productos

Use case: product-mockup. Asset type: square ecommerce catalog photograph for a
fictional technology shop BYTEDMEX, showcased in NFORCE web design portfolio.
Primary request: [subject]. One product only, centered and entirely visible with
14 percent breathing room on all sides. Photorealistic luxury studio product
photography, charcoal seamless background #17191D with soft grounded shadow,
gentle softbox highlights, accurate realistic materials, sharp fine detail.
Consistent square composition. No typography, no letters, no logos, no brand marks,
no watermarks, no price labels, no extra objects, no border.

| Archivo en public/images | Subject                                                                                                                                                                                               |
| ------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| pc-noir.webp             | a complete premium black gaming desktop PC tower, tempered glass side panel, neatly assembled internal GPU, three subtle acid-lime illuminated cooling fans, no loose parts, three quarter front view |
| pc-arctic.webp           | a complete premium white gaming desktop PC tower, panoramic tempered glass, neatly assembled components, three subtle ice-blue illuminated fans, three quarter front view                             |
| gpu.webp                 | one powerful fictional graphics card with three large black fans, matte graphite shroud and subtle acid-lime edge accent, three quarter product view                                                  |
| mainboard.webp           | one fictional black ATX gaming motherboard, detailed socket, heat sinks, RAM slots and PCIe slots, subtle lime accent, three quarter top-down view                                                    |
| memory.webp              | a matching pair of premium matte-black desktop RAM modules with slim acid-lime top diffusers, arranged diagonally as a cohesive kit                                                                   |
| monitor.webp             | one premium ultrawide curved gaming monitor on a minimal black stand, display showing an abstract dark green atmospheric landscape, three quarter view                                                |
| keyboard.webp            | one compact 75 percent mechanical gaming keyboard, black and warm gray keys, subtle lime accent keys, coiled cable, three quarter top view                                                            |
| headset.webp             | one premium black wireless gaming headset with over-ear cushions, small boom microphone and subtle lime trim, elegant three quarter view                                                              |

## Prompt común: cuatro componentes adicionales

Use case: product-mockup. Square ecommerce catalog photograph for a fictional
premium gaming hardware store. [subject]. Exactly one product, centered and fully
visible, 14 percent empty breathing room on all sides. Charcoal seamless background
#17191D, soft studio lighting, restrained lime accent, realistic materials and crisp
details, subtle grounded shadow. No words, no logos, no letters, no watermarks,
no labels, no extra objects. Match a cohesive luxury dark hardware catalog.

| Archivo en public/images | Subject                                                                                                                                |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------- |
| cpu.webp                 | one fictional premium desktop CPU processor, metallic square heat spreader on a dark substrate, front three-quarter macro product view |
| ssd.webp                 | one fictional black NVMe SSD drive with a finely machined compact graphite heatsink, angled diagonally, subtle lime detail             |
| mouse.webp               | one fictional premium black wireless gaming mouse with ergonomic shape, subtle acid-lime scroll wheel and side buttons                 |
| hub.webp                 | one fictional premium matte-black USB-C desktop hub, compact aluminum body with seven ports and short cable                            |

Las imágenes ilustran conceptos de producto, no modelos reales ni productos disponibles.
