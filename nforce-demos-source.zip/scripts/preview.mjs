import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
const root = resolve('site');
const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript',
    '.css': 'text/css',
    '.jpg': 'image/jpeg',
    '.png': 'image/png',
    '.mp4': 'video/mp4',
    '.svg': 'image/svg+xml',
};
http.createServer(async (request, response) => {
    try {
        let path = resolve(
            root,
            '.' + decodeURIComponent(new URL(request.url, 'http://localhost').pathname),
        );
        if (path !== root && !path.startsWith(root + sep)) throw new Error('Path');
        if ((await stat(path)).isDirectory()) path += '/index.html';
        const bytes = await readFile(path);
        response.writeHead(200, {
            'Content-Type': types[extname(path)] || 'application/octet-stream',
            'Content-Length': bytes.length,
            'Cache-Control': 'no-cache',
        });
        response.end(bytes);
    } catch {
        response.writeHead(404);
        response.end('Not found');
    }
}).listen(8778, '127.0.0.1', () => console.log('http://127.0.0.1:8778/'));
