import { cp, mkdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('../', import.meta.url));
await mkdir(root + 'site/braza', { recursive: true });
await cp(root + 'apps/braza/index.html', root + 'site/braza/index.html');
await cp(root + 'apps/braza/assets', root + 'site/braza/assets', { recursive: true });
await cp(root + 'catalog/index.html', root + 'site/index.html');
await cp(root + 'catalog/viaje-preview.jpg', root + 'site/viaje-ya/preview.jpg');
await writeFile(root + 'site/.nojekyll', '');
console.log('Tres demos listas en site/.');

await cp(root + 'catalog/assets', root + 'site/assets', { recursive: true });
for (const file of ['designs.css', 'designs.js', 'designs-i18n.js']) await cp(root + 'catalog/' + file, root + 'site/' + file);
