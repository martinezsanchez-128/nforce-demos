import { mkdir, writeFile } from 'node:fs/promises';
const base = 'https://martinezsanchez-128.github.io/nforce-demos/';
const groups = [
    ['apps/braza/assets', ['film-scrub']],
    ['apps/meridian/public/assets', ['arrival', 'entrance', 'flow', 'terrace']],
];
for (const [directory, names] of groups) {
    await mkdir(directory, { recursive: true });
    for (const name of names) {
        const response = await fetch(base + name + '.mp4');
        if (!response.ok) throw new Error(`Cannot download ${name}: ${response.status}`);
        await writeFile(`${directory}/${name}.mp4`, new Uint8Array(await response.arrayBuffer()));
        console.log(`Restored ${name}`);
    }
}
