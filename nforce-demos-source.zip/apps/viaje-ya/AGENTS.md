# Reglas de mantenimiento de ViajeYa

- Mantener los textos y datos en `src/lib/content.ts` y los recursos originales en `src/lib/assets.ts`.
- Definir colores en los tokens de `@theme static` de `src/index.css`. Consultarlos con variables; no agregar hexadecimales en componentes.
- Usar `SectionBackdrop` para las capas de fondo de pantalla completa. Conservar los nombres de capas usados por GSAP.
- Mantener un único timeline maestro y un único pin en `FlightFilm.tsx`.
- No extraer la geometría visual `WINDOW_GLASS`, `PLANE_FIT` o `PIN_POS` al archivo de contenido.
- El fondo original se compone de imágenes; no sustituir la escena por video o canvas sin una solicitud explícita.
- Preservar los encuadres coincidentes del avión, recorte y mapa.
- Respetar movimiento reducido, controles táctiles y navegación por teclado.
- Ejecutar el build de la raíz y revisar escritorio/móvil después de cambios funcionales.
- Mantener el código fuente formateado, con componentes y nombres claros. No versionar `node_modules`, archivos de salida ni prompts de pago.
