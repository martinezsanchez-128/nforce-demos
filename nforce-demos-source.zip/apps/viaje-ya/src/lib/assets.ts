/**
 * Todas las imágenes del sitio, en un solo lugar.
 *
 * Se sirven directo desde el CDN de Higgsfield (CloudFront): no hay nada en
 * `public/`. Para mudar el set completo a otro CDN, cambiá `HF_BASE`.
 *
 * Generadas con GPT Image 2 · 1K · quality high · 16:9 (1344×752). Los
 * prompts y los job_id están en `referencia/generadas/ASSETS.md`.
 */
const HF_BASE = 'https://d8j0ntlcm91z4.cloudfront.net/user_3Bd1EO6EIHxSqCgleKKy9qZ3l1v';

export const HF = {
    /** Pared de cabina con la ventanilla centrada. */
    window: `${HF_BASE}/hf_20260921_230200_f2ea2a56-4660-4de4-9148-8fe4d9103ed7.png`,
    /** Mar de nubes a sangre: lo que hay del otro lado del vidrio. */
    clouds: `${HF_BASE}/hf_20260921_230202_ab77d370-c984-4fc6-94a4-1a0c843c9d86.png`,
    /** Avión visto desde arriba sobre fondo arena. */
    plane: `${HF_BASE}/hf_20260921_230421_97bd1e2b-3f27-4908-b17c-483a6d77a58b.png`,
    /** `plane` sin fondo (remove_background): mismo encuadre, sin sombra
      (la sombra la pone el CSS). Con esto el título pasa detrás del avión. */
    planeCutout: `${HF_BASE}/hf_20260921_233720_e7e8436d-712d-4192-ad7c-e54f4803e272.png` as string,
    /** El mismo avión en línea, sobre el mapa del viaje (generado con `plane` de referencia). */
    map: `${HF_BASE}/hf_20260921_230542_4c3b09b0-d8e5-4f1c-8eb9-0a198227b974.png`,
} as const;
