/* ══════════════════════════════════════════════════════════════════
   ESTE ES EL ÚNICO ARCHIVO QUE NECESITÁS TOCAR.

   Acá viven los textos, las imágenes, los fondos y los datos de todo
   el sitio. Los colores y las tipografías están aparte, en
   `src/index.css`, arriba de todo.

   Si cambiás algo acá, cambia en computadora y en celular a la vez.
   ══════════════════════════════════════════════════════════════════ */
import { HF } from '@/lib/assets';
import type { Layer } from '@/components/ui/SectionBackdrop';

/* ─────────────── 1. MARCA ─────────────── */
export const BRAND = {
    /** El nombre, en dos partes: la segunda va en el color de acento. */
    name: ['VIAJE', 'YA'] as const,
    phone: '+52 81 3594 5656',
    email: 'cdms28@hotmail.com',
};

/* ─────────────── 2. MENÚ Y BOTÓN FIJO ─────────────── */
export const NAV = [
    { label: 'Destinos', href: '#' },
    { label: 'Cómo funciona', href: '#' },
    { label: 'Planes', href: '#' },
    { label: 'Contacto', href: '#' },
];

/** Lo que muestra la barra en celular, donde no entra el menú completo. */
export const HEADER = { menuLabel: 'Menú', contactShort: 'Contacto' };

/** El botón que queda siempre abajo, en el centro. */
export const CTA = {
    label: 'Arma mi viaje',
    href: 'https://wa.me/528135945656?text=Hola%20NFORCE%2C%20me%20interesa%20el%20dise%C3%B1o%20de%20agencia%20de%20viajes.',
};

/* ─────────────── 3. IMÁGENES ───────────────
   Si cambiás el avión o el mapa, tienen que seguir siendo el MISMO avión
   en la misma posición: el efecto final funde uno en el otro.
   Si cambiás la ventanilla, revisá `WINDOW_GLASS` en FlightFilm.tsx
   (el recorte del vidrio está medido sobre esta imagen). */
export const MEDIA = {
    window: HF.window,
    clouds: HF.clouds,
    plane: HF.plane,
    /** El avión recortado, sin fondo. Si está, el título gigante pasa POR
      DETRÁS del avión; si queda vacío (""), el título va por delante. */
    planeCutout: HF.planeCutout,
    map: HF.map,
};

/** Descripción de cada imagen, para lectores de pantalla y buscadores. */
export const ALT = {
    plane: 'Avión de VIAJE YA visto desde arriba',
    map: 'Mapa del viaje: vuelo, hotel, traslado y excursión',
};

/* ─────────────── 3b. EL FONDO DE LA PELÍCULA ───────────────
   Lo que se ve del otro lado del vidrio. Las capas se pintan de arriba
   hacia abajo: la PRIMERA de la lista es la que queda más atrás.

   Para cambiar las nubes por otra foto, cambiá el `src` de la primera.
   Para poner un video en vez de las nubes:
       { type: "video", src: "https://tu-video.mp4", poster: "https://tu-foto.jpg", name: "clouds" },
   Para un color liso:
       { type: "color", value: "var(--color-sand)", name: "clouds" },

   Dejá siempre el `name` ("clouds", "sky-veil"): es lo que usa la
   película para agrandar las nubes y azular el cielo. Si sacás la capa
   "sky-veil", el cielo simplemente no se azula.

   Tipos disponibles: "image" · "video" · "color" · "gradient". */
export const BACKGROUNDS: Record<string, Layer[]> = {
    film: [
        { type: 'image', src: MEDIA.clouds, name: 'clouds' },
        {
            type: 'gradient',
            name: 'sky-veil',
            opacity: 0,
            value: 'linear-gradient(180deg, color-mix(in srgb, var(--color-sky) 55%, transparent) 0%, color-mix(in srgb, var(--color-sky-soft) 25%, transparent) 55%, transparent 100%)',
        },
    ],
};

/* ─────────────── 4. HERO (la ventanilla) ─────────────── */
export const HERO = {
    left: ['Tú eliges', 'el destino'],
    right: ['Nosotros,', 'todo lo demás'],
    kicker: ['Tu viaje armado', 'sin mover un dedo'],
    body: 'Vuelos, hoteles, traslados y excursiones en un solo itinerario. Nos cuentas a dónde quieres ir y nos ocupamos del resto.',
    scrollCue: '↓ Desliza',
    scrollCueRight: 'para despegar',
};

/* ─────────────── 5. DETRÁS DEL VIDRIO (las nubes) ─────────────── */
export const STATEMENT =
    'VIAJE YA arma tu viaje de punta a punta. Más de 18.000 viajeros ya despegaron sin hacer una sola reserva: ellos eligieron el destino, nosotros resolvimos todo lo demás.';

export const FEATURES = [
    {
        title: ['Vuelos', 'resueltos'],
        text: 'Buscamos las mejores combinaciones, escalas y horarios. Tú solo recibes tus pasajes listos.',
    },
    {
        title: ['Hoteles', 'elegidos'],
        text: 'Alojamientos que visitamos y verificamos, en la zona justa para lo que quieres hacer.',
    },
    {
        title: ['Traslados', 'puerta a puerta'],
        text: 'Del aeropuerto al hotel y del hotel a cada excursión. Nadie te deja esperando.',
    },
    {
        title: ['Asistencia', '24/7'],
        text: 'Si algo cambia en el camino, lo resolvemos nosotros antes de que te des cuenta.',
    },
];

/* ─────────────── 6. EL AVIÓN ─────────────── */
/** El título gigante que queda detrás del avión. */
export const PLANE_TITLE = { left: 'Viaja sin', right: 'vueltas' };

export const SPECS = {
    kicker: 'Tu itinerario',
    title: 'A medida',
    /** Los números cuentan desde 0 al llegar. `suffix` va pegado al número. */
    stats: [
        { label: 'Destinos', value: 120, suffix: '+' },
        { label: 'Armado del viaje', value: 48, suffix: ' h' },
        { label: 'Viajeros felices', value: 18000, suffix: '+' },
        { label: 'Proveedores verificados', value: 350, suffix: '' },
        { label: 'Ahorro promedio', value: 22, suffix: '%' },
        { label: 'Asistencia', value: 24, suffix: '/7' },
    ],
    sideKicker: 'Llave en mano',
    side: 'Nos dices cuándo, con quién y qué te gusta. En 48 horas tienes un itinerario completo, con cada reserva hecha y cada traslado coordinado.',
};

/** Las etiquetas que aparecen sobre los pines del mapa, en orden:
    avión, hotel, auto, cámara (así vienen dibujados en la imagen). */
export const MAP_PINS = ['Vuelo', 'Hotel', 'Traslado', 'Excursión'];

/** Cuánto scroll dura toda la película, en % de alto de pantalla.
    Más chico = hay que scrollear menos para ver todo. */
export const FILM_LENGTH = { desktop: 850, mobile: 760 };

/** Contacto de la empresa que presenta este concepto. */
export const CONTACT = {
    name: 'NFORCE Technologies',
    location: 'Nuevo León, México',
    caption: 'Diseño de demostración · Contacta a NFORCE para un sitio como este.',
    back: 'Explorar otros diseños',
};
