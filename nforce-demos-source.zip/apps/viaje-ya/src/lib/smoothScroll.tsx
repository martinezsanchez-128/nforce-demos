import { useEffect, type ReactNode } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

/** La instancia activa de Lenis, para frenar el scroll durante la intro. */
export const lenisRef: { current: Lenis | null } = { current: null };

/** Lenis alimentado por el ticker de GSAP, así ScrollTrigger y el scroll suave
    leen el mismo reloj. Con `prefers-reduced-motion` no se monta. */
export function SmoothScroll({ children }: { children: ReactNode }) {
    useEffect(() => {
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

        const lenis = new Lenis({ lerp: 0.085, syncTouch: true, syncTouchLerp: 0.07 });
        lenisRef.current = lenis;
        lenis.on('scroll', ScrollTrigger.update);
        const update = (time: number) => lenis.raf(time * 1000);
        gsap.ticker.add(update);
        gsap.ticker.lagSmoothing(0);

        return () => {
            gsap.ticker.remove(update);
            lenis.destroy();
            lenisRef.current = null;
        };
    }, []);

    return <>{children}</>;
}
