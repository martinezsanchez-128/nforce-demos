import type { ComponentType } from 'react';

import { FlightFilm } from '@/components/FlightFilm';

/* ══════════════════════════════════════════════════════════════════
   LAS SECCIONES DEL SITIO, EN ORDEN DE APARICIÓN.

   · Para SACAR una sección:  poné `active: false` (no borres la línea).
   · Para MOVER una sección:  subí o bajá su línea.
   · Para AGREGAR una:        creá el componente en src/components/sections
                              y sumá su línea acá.
   ══════════════════════════════════════════════════════════════════ */

export type SectionEntry = {
    id: string;
    active: boolean;
    Component: ComponentType;
    /** Clave de `BACKGROUNDS` en content.ts, o null si no tiene fondo propio. */
    background: string | null;
};

export const SECTIONS: SectionEntry[] = [
    /* Ventanilla → nubes → beneficios → avión → mapa del viaje, en un solo plano. */
    { id: 'film', active: true, Component: FlightFilm, background: 'film' },
];

/** Las secciones encendidas, en orden. */
export const activeSections = () => SECTIONS.filter((s) => s.active);
