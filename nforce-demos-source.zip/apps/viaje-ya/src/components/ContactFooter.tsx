import { BRAND, CONTACT } from '@/lib/content';

export function ContactFooter() {
    return (
        <footer className="relative z-10 bg-ink px-6 py-16 pb-28 text-paper md:px-12">
            <div className="mx-auto flex max-w-6xl flex-col justify-between gap-7 md:flex-row">
                <div>
                    <p className="text-lg font-semibold">{CONTACT.name}</p>
                    <p className="mt-2 text-sm opacity-70">{CONTACT.location}</p>
                    <p className="mt-3 max-w-sm text-xs leading-relaxed opacity-60">
                        {CONTACT.caption}
                    </p>
                </div>
                <div className="flex flex-col items-start gap-3 text-sm">
                    <a href={`tel:${BRAND.phone.replaceAll(' ', '')}`}>{BRAND.phone}</a>
                    <a href={`mailto:${BRAND.email}`}>{BRAND.email}</a>
                    <a className="mt-2 text-xs underline underline-offset-4" href="../">
                        {CONTACT.back}
                    </a>
                </div>
            </div>
        </footer>
    );
}
