import type { MouseEvent } from 'react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BRAND, HEADER, NAV } from '@/lib/content';
import { lenisRef } from '@/lib/smoothScroll';
import { Logo } from './Logo';

/** Cada enlace lleva a un capítulo de la misma película, sin crear secciones falsas. */
function goToChapter(event: MouseEvent<HTMLAnchorElement>, index: number) {
    event.preventDefault();
    if (index === 3) {
        window.location.href = `mailto:${BRAND.email}`;
        return;
    }
    const film = ScrollTrigger.getAll().find((trigger) => trigger.vars.pin);
    const progress = [0.99, 0.43, 0.77][index] ?? 0;
    const target = film ? film.start + progress * (film.end - film.start) : 0;
    if (lenisRef.current) lenisRef.current.scrollTo(target);
    else window.scrollTo({ top: target, behavior: 'smooth' });
}

export function Header() {
    return (
        <header
            data-header
            className="fixed inset-x-0 top-0 z-50 text-paper"
            style={{ color: 'var(--header-color, var(--color-paper))' }}
        >
            <div className="mx-auto grid grid-cols-[1fr_auto_1fr] items-center gap-4 px-5 py-5 md:px-10 md:py-7">
                <nav className="hidden gap-7 text-[13px] font-medium md:flex">
                    {NAV.map((item, index) => (
                        <a
                            key={item.label}
                            href={item.href}
                            onClick={(event) => goToChapter(event, index)}
                            className="opacity-90 transition-opacity hover:opacity-60"
                        >
                            {item.label}
                        </a>
                    ))}
                </nav>
                <a
                    href={`mailto:${BRAND.email}`}
                    className="text-[12px] font-medium opacity-90 md:hidden"
                >
                    {HEADER.menuLabel}
                </a>
                <a
                    href="#"
                    data-header-logo
                    className="text-[13px] opacity-0 md:text-[15px]"
                    onClick={(event) => {
                        event.preventDefault();
                        if (lenisRef.current) lenisRef.current.scrollTo(0);
                        else window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                >
                    <Logo />
                </a>
                <div className="flex justify-end gap-7 text-[13px] font-medium">
                    <a
                        href={`tel:${BRAND.phone.replaceAll(' ', '')}`}
                        className="hidden opacity-90 transition-opacity hover:opacity-60 lg:inline"
                    >
                        {BRAND.phone}
                    </a>
                    <a
                        href={`mailto:${BRAND.email}`}
                        className="opacity-90 transition-opacity hover:opacity-60"
                    >
                        <span className="hidden sm:inline">{BRAND.email}</span>
                        <span className="sm:hidden">{HEADER.contactShort}</span>
                    </a>
                </div>
            </div>
        </header>
    );
}
