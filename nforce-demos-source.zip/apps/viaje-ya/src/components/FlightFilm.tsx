import { useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';

import {
    ALT,
    BACKGROUNDS,
    BRAND,
    FEATURES,
    FILM_LENGTH,
    HERO,
    MAP_PINS,
    MEDIA,
    PLANE_TITLE,
    SPECS,
    STATEMENT,
} from '@/lib/content';
import { lenisRef } from '@/lib/smoothScroll';
import { Logo } from '@/components/Logo';
import { SectionBackdrop } from '@/components/ui/SectionBackdrop';

gsap.registerPlugin(ScrollTrigger);

/* ── Medidas sobre las imágenes (1344×752) ────────────────────────────
   Si cambiás la ventanilla, el avión o el mapa, estas medidas cambian. */

/** El vidrio de la ventanilla: el agujero por donde se ven las nubes.
    Recortado 3px hacia adentro para que nunca asome un borde. */
const WINDOW_GLASS = {
    path: 'M548 161H789A40 90 0 0 1 829 251V453A150 140 0 0 1 679 593H658A150 140 0 0 1 508 453V251A40 90 0 0 1 548 161Z',
    width: 321 / 1344,
    height: 432 / 752,
    /** Centro del vidrio, en % de la caja: el zoom se hace desde acá. */
    origin: '49.74% 50.13%',
};

/** En el mapa el avión de línea salió 0,88× más chico y 2,8% más arriba que
    en la foto: la foto termina su zoom en esa pose para que el fundido calce. */
const PLANE_FIT = { scale: 0.88, xPercent: 0.25, yPercent: -2.8 };

/** Posición de cada pin del mapa, en % de la caja (avión, hotel, auto, cámara).
    `align` evita que la etiqueta de un pin pegado al borde quede cortada. */
const PIN_POS = [
    { x: 7.8, y: 26.9, align: 'left' },
    { x: 24.9, y: 79.4, align: 'center' },
    { x: 78.9, y: 82.8, align: 'center' },
    { x: 91.1, y: 33.9, align: 'right' },
] as const;

const ALIGN = { left: '-12%', center: '-50%', right: '-88%' } as const;

const holeMask = `url("data:image/svg+xml,${encodeURIComponent(
    `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1344 752' preserveAspectRatio='none'><path fill-rule='evenodd' fill='#000' d='M0 0H1344V752H0Z ${WINDOW_GLASS.path}'/></svg>`,
)}")`;

const fmt = (n: number) => Math.round(n).toLocaleString('es-AR');
const isPortrait = () => window.matchMedia('(max-aspect-ratio: 1/1)').matches;

/** Un color del `@theme` de index.css, ya resuelto: GSAP no sabe animar `var()`. */
const token = (name: string) =>
    getComputedStyle(document.documentElement).getPropertyValue(`--color-${name}`).trim();

/** Las fotos del fondo de la película, para cargarlas junto con el resto. */
const backdropImages = BACKGROUNDS.film.flatMap((l) =>
    l.type === 'image' ? [l.src] : l.type === 'video' ? [l.poster] : [],
);

/** Descarga y decodifica todas las imágenes antes de mostrar nada: así la
    película nunca "aparece de golpe" a mitad del scroll. */
function preload(srcs: string[], onProgress: (p: number) => void) {
    let done = 0;
    return Promise.all(
        srcs.map(
            (src) =>
                new Promise<void>((resolve) => {
                    const img = new Image();
                    const finish = () => {
                        done += 1;
                        onProgress(done / srcs.length);
                        resolve();
                    };
                    img.onload = () => img.decode().then(finish, finish);
                    img.onerror = finish;
                    img.src = src;
                }),
        ),
    );
}

/**
 * La película completa, en un solo plano fijado:
 * intro (la ventanilla sube) → zoom a través del vidrio → nubes (manifiesto +
 * beneficios) → arena con el avión que llega → ficha con contadores → el avión
 * se funde en el mapa del viaje.
 */
export function FlightFilm() {
    const root = useRef<HTMLElement>(null);
    const hasCutout = Boolean(MEDIA.planeCutout);

    useGSAP(
        () => {
            const q = gsap.utils.selector(root);
            const header = document.querySelector<HTMLElement>('[data-header]');
            const headerLogo = document.querySelector<HTMLElement>('[data-header-logo]');
            const pill = document.querySelector<HTMLElement>('[data-pill]');
            const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            const win = q('.win-box')[0] as HTMLElement;
            const photo = q('.plane-photo')[0] as HTMLElement;

            /* Al recargar (F5) siempre se arranca desde arriba, con la intro. */
            if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
            window.scrollTo(0, 0);

            gsap.set([win, q('.plane-box')], { xPercent: -50, yPercent: -50 });
            gsap.set(win, { transformOrigin: WINDOW_GLASS.origin });
            const paper = token('paper');
            const ink = token('ink');
            if (header) gsap.set(header, { '--header-color': paper });

            /* ── Intro: estado inicial ── */
            if (!reduce) {
                gsap.set(q('.win-inner'), { y: '55vh', scale: 0.9 });
                gsap.set(q('.intro-up'), { yPercent: 115 });
                gsap.set(q('.intro-fade'), { opacity: 0, y: 16 });
                gsap.set([header, pill], { opacity: 0 });
                document.documentElement.style.overflow = 'hidden';
            }

            const counter = q('.loader-count')[0] as HTMLElement;
            let alive = true;

            preload(
                [MEDIA.window, ...backdropImages, MEDIA.plane, MEDIA.map, MEDIA.planeCutout].filter(
                    Boolean,
                ),
                (p) => {
                    if (counter) counter.textContent = String(Math.round(p * 100)).padStart(2, '0');
                },
            ).then(() => {
                if (!alive) return;
                lenisRef.current?.stop();
                const intro = gsap.timeline({
                    defaults: { ease: 'expo.out' },
                    onComplete: () => {
                        document.documentElement.style.overflow = '';
                        lenisRef.current?.start();
                        ScrollTrigger.refresh();
                    },
                });
                intro.to(q('.loader'), { autoAlpha: 0, duration: 0.7, ease: 'power2.inOut' }, 0.15);
                if (!reduce) {
                    intro
                        .to(q('.win-inner'), { y: 0, scale: 1, duration: 1.8 }, 0.35)
                        .to(q('.intro-up'), { yPercent: 0, stagger: 0.08, duration: 1.3 }, 0.95)
                        .to(q('.intro-fade'), { opacity: 1, y: 0, stagger: 0.08, duration: 1 }, 1.3)
                        .to([header, pill], { opacity: 1, duration: 1, ease: 'power2.out' }, 1.4);
                }
            });

            /* Cuánto hay que agrandar la ventanilla para que el vidrio cubra toda la
         pantalla (con margen para las esquinas redondeadas). */
            const zoomOut = () => {
                const w = win.offsetWidth * WINDOW_GLASS.width;
                const h = win.offsetHeight * WINDOW_GLASS.height;
                return Math.max(window.innerWidth / w, window.innerHeight / h) * 1.35;
            };

            const tl = gsap.timeline({
                defaults: { ease: 'none' },
                scrollTrigger: {
                    trigger: root.current,
                    start: 'top top',
                    end: () => `+=${isPortrait() ? FILM_LENGTH.mobile : FILM_LENGTH.desktop}%`,
                    pin: true,
                    scrub: reduce ? true : 1,
                    invalidateOnRefresh: true,
                },
            });

            /* 1 · A través de la ventanilla (0 → Z).
         En celular el vidrio cubre la pantalla con muy poco agrandamiento, así
         que el zoom recibe más recorrido de scroll (Z = 5 en vez de 3) para no
         sentirse como un corte. Las nubes se agrandan a la par de la ventana:
         si se achicaran, anularían la sensación de avanzar. */
            const Z = isPortrait() ? 5 : 3;
            const at = (t: number) => t + (Z - 3); // corre todo lo que viene después
            const k = Z / 3;

            tl.to(win, { scale: zoomOut, ease: 'power2.in', duration: Z }, 0)
                .fromTo(
                    q('.clouds'),
                    { scale: 1 },
                    { scale: 1.18, duration: Z, ease: 'power1.in' },
                    0,
                )
                .to(q('.clouds'), { scale: 1.08, duration: 3, ease: 'power1.out' }, Z)
                .to(
                    q('.hero-left'),
                    { xPercent: -60, opacity: 0, duration: 1.6 * k, ease: 'power1.in' },
                    0,
                )
                .to(
                    q('.hero-right'),
                    { xPercent: 60, opacity: 0, duration: 1.6 * k, ease: 'power1.in' },
                    0,
                )
                .to(q('.hero-meta'), { y: 40, opacity: 0, duration: 1 * k }, 0)
                .to(q('.glass-logo'), { opacity: 0, duration: 0.8 * k }, 0.4 * k)
                .to(headerLogo, { opacity: 1, duration: 0.8 }, 1.4 * k)
                .fromTo(
                    header,
                    { '--header-color': paper },
                    { '--header-color': ink, duration: 0.8 },
                    2 * k,
                )
                .set(win, { autoAlpha: 0 }, Z);

            /* 2 · El manifiesto sobre las nubes */
            tl.fromTo(q('.statement'), { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.6 }, at(2.6))
                .fromTo(
                    q('.statement .w'),
                    { opacity: 0.12 },
                    { opacity: 1, stagger: 0.09, duration: 0.5 },
                    at(3),
                )
                .to(q('.statement'), { yPercent: -30, opacity: 0, duration: 1 }, at(6.6));

            /* 3 · Beneficios, con el cielo que se azula */
            tl.to(q('.sky-veil'), { opacity: 1, duration: 1.5 }, at(7))
                .fromTo(
                    q('.feature'),
                    { y: 60, opacity: 0 },
                    { y: 0, opacity: 1, stagger: 0.18, duration: 0.8, ease: 'power2.out' },
                    at(7.6),
                )
                .to(q('.features'), { yPercent: -25, opacity: 0, duration: 1 }, at(10.2));

            /* 4 · Arena + el avión que llega */
            tl.to(q('.sand'), { opacity: 1, duration: 1.4 }, at(10.8))
                .fromTo(
                    q('.plane-title > *'),
                    { yPercent: 40, opacity: 0 },
                    { yPercent: 0, opacity: 1, stagger: 0.15, duration: 1, ease: 'power2.out' },
                    at(11.4),
                )
                .fromTo(
                    photo,
                    { scale: 2.5, yPercent: 32, xPercent: 0, opacity: 0 },
                    { ...PLANE_FIT, opacity: 1, duration: 3.2, ease: 'power2.out' },
                    at(12),
                )
                .to(q('.plane-title'), { opacity: 0, duration: 1 }, at(14.6));

            /* 5 · Ficha con contadores */
            tl.fromTo(
                q('.spec'),
                { y: 30, opacity: 0 },
                { y: 0, opacity: 1, stagger: 0.12, duration: 0.8, ease: 'power2.out' },
                at(15),
            );
            q('.stat-num').forEach((el, i) => {
                const stat = SPECS.stats[i];
                const c = { v: 0 };
                tl.to(
                    c,
                    {
                        v: stat.value,
                        duration: 1.6,
                        ease: 'power2.out',
                        onUpdate: () => {
                            el.textContent = fmt(c.v) + stat.suffix;
                        },
                    },
                    at(15.3 + i * 0.08),
                );
            });

            /* 6 · El avión se desvanece en el mapa del viaje.
         En celular la caja se aleja un poco para que entren los 4 pines. */
            tl.to(photo, { opacity: 0, duration: 2 }, at(18))
                .fromTo(q('.plane-map'), { opacity: 0 }, { opacity: 1, duration: 2 }, at(18))
                .to(
                    q('.plane-box'),
                    { scale: () => (isPortrait() ? 0.62 : 1), duration: 2, ease: 'power1.inOut' },
                    at(18),
                )
                .to(q('.sand'), { backgroundColor: token('sand-map'), duration: 2 }, at(18))
                .fromTo(
                    q('.pin-label'),
                    { y: 12, opacity: 0 },
                    { y: 0, opacity: 1, stagger: 0.2, duration: 0.6, ease: 'back.out(2)' },
                    at(19.4),
                )
                .to({}, { duration: 1.2 });

            return () => {
                alive = false;
                document.documentElement.style.overflow = '';
            };
        },
        { scope: root },
    );

    return (
        <section
            ref={root}
            className="relative h-screen w-full overflow-hidden bg-cabin"
            aria-label={BRAND.name.join(' ')}
        >
            {/* Del otro lado del vidrio: las nubes y el cielo que se azula (BACKGROUNDS.film) */}
            <SectionBackdrop layers={BACKGROUNDS.film} />

            {/* Manifiesto */}
            <div className="statement invisible absolute inset-0 flex items-center px-5 md:px-[8vw]">
                <p className="display max-w-[1150px] text-[clamp(2rem,4vw,4.4rem)] !leading-[1.02] text-ink">
                    {STATEMENT.split(' ').map((w, i) => (
                        <span key={i} className="w">
                            {w}{' '}
                        </span>
                    ))}
                </p>
            </div>

            {/* Beneficios */}
            <div className="features absolute inset-0 flex items-center px-5 md:px-[6vw]">
                <div className="grid w-full grid-cols-1 gap-x-10 gap-y-7 sm:grid-cols-2 lg:grid-cols-4">
                    {FEATURES.map((f) => (
                        <article key={f.title.join()} className="feature text-ink opacity-0">
                            <span className="mb-4 block h-[2px] w-8 bg-accent" />
                            <h3 className="display text-[clamp(1.5rem,2.3vw,2.4rem)] !leading-[0.95]">
                                {f.title[0]}
                                <br />
                                {f.title[1]}
                            </h3>
                            <p className="mt-3 max-w-[30ch] text-[14px] leading-relaxed text-ink/70">
                                {f.text}
                            </p>
                        </article>
                    ))}
                </div>
            </div>

            {/* Arena: fondo del avión */}
            <div className="sand absolute inset-0 bg-sand opacity-0">
                {/* Título gigante: detrás del avión solo si hay recorte */}
                {hasCutout && <PlaneTitle />}

                <div className="plane-box">
                    <img
                        src={MEDIA.map}
                        alt={ALT.map}
                        className="plane-map absolute inset-0 size-full opacity-0"
                    />
                    <img
                        src={hasCutout ? MEDIA.planeCutout : MEDIA.plane}
                        alt={ALT.plane}
                        className={`plane-photo absolute inset-0 size-full opacity-0 ${hasCutout ? 'plane-photo--cutout' : 'plane-photo--bg'}`}
                    />
                    {MAP_PINS.map((label, i) => (
                        <span
                            key={label}
                            className="pin-label absolute whitespace-nowrap rounded-full bg-ink px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.14em] text-paper opacity-0 md:text-[11px]"
                            style={{
                                left: `${PIN_POS[i].x}%`,
                                top: `calc(${PIN_POS[i].y}% + 1.6vw)`,
                                translate: `${ALIGN[PIN_POS[i].align]} 0`,
                            }}
                        >
                            {label}
                        </span>
                    ))}
                </div>

                {!hasCutout && <PlaneTitle front />}

                {/* Ficha */}
                <div className="pointer-events-none absolute inset-0 px-5 pt-20 md:px-[4vw] md:pt-[16vh]">
                    <div className="flex h-full flex-col justify-between pb-28 md:flex-row md:pb-[14vh]">
                        <div className="flex h-full flex-col justify-between text-ink md:block md:h-auto md:max-w-[30vw]">
                            <div>
                                <p className="spec text-[12px] font-semibold uppercase tracking-[0.2em] text-ink/60">
                                    {SPECS.kicker}
                                </p>
                                <h2 className="spec display mt-2 text-[clamp(3rem,7vw,7.5rem)]">
                                    {SPECS.title}
                                </h2>
                                <p className="spec mt-3 max-w-[34ch] text-[13px] leading-relaxed text-ink/70 md:hidden">
                                    {SPECS.side}
                                </p>
                            </div>
                            <dl className="grid grid-cols-3 gap-x-4 gap-y-4 md:mt-[8vh] md:grid-cols-2 md:gap-x-8 md:gap-y-6">
                                {SPECS.stats.map((s) => (
                                    <div key={s.label} className="spec">
                                        <dt className="text-[9px] font-semibold uppercase tracking-[0.16em] text-ink/55 md:text-[10px]">
                                            {s.label}
                                        </dt>
                                        <dd className="stat-num mt-1 font-display text-[18px] font-medium tracking-tight md:text-[26px]">
                                            0{s.suffix}
                                        </dd>
                                    </div>
                                ))}
                            </dl>
                        </div>
                        <div className="hidden max-w-[26vw] text-ink md:block">
                            <p className="spec text-[12px] font-semibold uppercase tracking-[0.2em] text-ink/60">
                                {SPECS.sideKicker}
                            </p>
                            <p className="spec mt-4 text-[15px] leading-relaxed text-ink/75">
                                {SPECS.side}
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            {/* La cabina: la ventanilla con el vidrio recortado */}
            <div className="win-box" style={{ containerType: 'inline-size' }}>
                <div className="win-inner absolute inset-0">
                    {/* Pared estirada arriba y abajo (solo se ve en pantallas verticales) */}
                    <div
                        className="absolute inset-x-0 bottom-[99.5%] h-[100vh]"
                        style={{ background: 'var(--gradient-wall-top)' }}
                    />
                    <div
                        className="absolute inset-x-0 top-[99.5%] h-[100vh]"
                        style={{ background: 'var(--gradient-wall-bottom)' }}
                    />
                    <img
                        src={MEDIA.window}
                        alt=""
                        className="absolute inset-0 size-full"
                        style={{
                            WebkitMaskImage: holeMask,
                            WebkitMaskSize: '100% 100%',
                            maskImage: holeMask,
                            maskSize: '100% 100%',
                        }}
                    />
                    <div className="glass-logo absolute left-1/2 top-[44%] -translate-x-1/2 text-paper">
                        <Logo />
                    </div>
                </div>
            </div>

            {/* Titulares del hero */}
            <h1 className="sr-only">
                {BRAND.name.join(' ')} — {HERO.left.join(' ')}, {HERO.right.join(' ')}
            </h1>
            <div
                aria-hidden
                className="hero-left display absolute left-5 top-[17vh] text-[clamp(3.2rem,8vw,10rem)] text-paper md:left-[4vw] md:top-[20vh]"
            >
                <Line>{HERO.left[0]}</Line>
                <Line>{HERO.left[1]}</Line>
            </div>
            <div
                aria-hidden
                className="hero-right display absolute bottom-[22vh] right-5 text-right text-[clamp(3.2rem,8vw,10rem)] text-paper md:bottom-auto md:right-[4vw] md:top-[52vh]"
            >
                <Line>{HERO.right[0]}</Line>
                <Line>{HERO.right[1]}</Line>
            </div>

            <div className="hero-meta absolute bottom-[12vh] left-5 max-w-[300px] text-paper md:bottom-[9vh] md:left-[4vw]">
                <p className="intro-fade font-display text-[20px] font-medium leading-[1.05] tracking-tight md:text-[24px]">
                    {HERO.kicker[0]}
                    <br />
                    {HERO.kicker[1]}
                </p>
                <span className="intro-fade my-4 hidden h-px w-8 bg-paper/60 md:block" />
                <p className="intro-fade hidden text-[13px] leading-relaxed text-paper/75 md:block">
                    {HERO.body}
                </p>
            </div>
            <div className="hero-meta absolute bottom-[9vh] right-[4vw] hidden gap-16 text-[11px] font-semibold uppercase tracking-[0.18em] text-paper/80 md:flex">
                <span className="intro-fade">{HERO.scrollCue}</span>
                <span className="intro-fade">{HERO.scrollCueRight}</span>
            </div>

            {/* Pantalla de carga: se va cuando todas las imágenes están listas */}
            <div className="loader fixed inset-0 z-[70] grid place-items-center bg-cabin text-paper">
                <div className="flex flex-col items-center gap-5">
                    <Logo className="text-[15px] md:text-[18px]" />
                    <span className="loader-count font-display text-[12px] tabular-nums tracking-[0.3em] text-paper/50">
                        00
                    </span>
                </div>
            </div>
        </section>
    );
}

/** Una línea de titular con máscara: el texto sube desde abajo en la intro. */
function Line({ children }: { children: string }) {
    return (
        <span className="block overflow-hidden pb-[0.06em]">
            <span className="intro-up block">{children}</span>
        </span>
    );
}

/** "Viajá sin · vueltas". `front`: va delante del avión, con multiplicar
    para que sobre el fuselaje blanco se lea igual que sobre la arena. */
function PlaneTitle({ front = false }: { front?: boolean }) {
    return (
        <div
            className="plane-title pointer-events-none absolute inset-x-0 top-1/2 flex -translate-y-1/2 flex-col justify-between gap-[30vh] px-5 text-ink md:flex-row md:items-center md:gap-0 md:px-[4vw]"
            style={front ? { mixBlendMode: 'multiply' } : undefined}
        >
            <span className="display text-[clamp(3.4rem,11vw,13rem)]">{PLANE_TITLE.left}</span>
            <span className="display self-end text-[clamp(3.4rem,11vw,13rem)] md:self-auto">
                {PLANE_TITLE.right}
            </span>
        </div>
    );
}
