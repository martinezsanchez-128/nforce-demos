import { Plane } from 'lucide-react';
import { BRAND, CTA } from '@/lib/content';

export function BookPill() {
    return (
        <a
            href={CTA.href === '#' ? `mailto:${BRAND.email}` : CTA.href}
            data-pill
            className="group fixed bottom-6 left-1/2 z-50 flex -translate-x-1/2 items-center gap-2 md:bottom-8"
        >
            <span className="whitespace-nowrap rounded-full bg-paper px-6 py-3 text-[14px] font-semibold text-ink shadow-[0_8px_30px_rgba(0,0,0,.18)] transition-transform duration-300 group-hover:-translate-y-0.5">
                {CTA.label}
            </span>
            <span className="grid size-11 place-items-center rounded-full bg-accent text-paper shadow-[0_8px_30px_color-mix(in_srgb,var(--color-accent)_35%,transparent)] transition-transform duration-500 group-hover:rotate-45">
                <Plane size={18} strokeWidth={2} />
            </span>
        </a>
    );
}
