import { BRAND } from '@/lib/content';

export function Logo({ className = '' }: { className?: string }) {
    return (
        <span
            className={`font-display whitespace-nowrap font-semibold uppercase tracking-[0.28em] ${className}`}
            aria-label={BRAND.name.join(' ')}
        >
            {BRAND.name[0]}
            <span className="ml-[0.4em] text-accent">{BRAND.name[1]}</span>
        </span>
    );
}
