import { useEffect, useRef } from 'react';

/**
 * El fondo de una sección, entero, en un solo lugar.
 *
 * Todo lo que pinta detrás del contenido —fotos, video, degradados, colores—
 * entra acá como una lista de capas. Fuera de este componente no puede existir
 * un `<video>` de fondo, un `<img>` a sangre ni un velo de degradado: esa es la
 * regla que evita que al cambiar un fondo queden capas huérfanas pintando por
 * debajo.
 *
 * El orden del array es el orden de pintado: la primera capa es la de más
 * atrás. Para sacar una capa se borra su línea en `BACKGROUNDS`.
 *
 * Solo se monta la rama del `type` activo. Cambiar `{ type: "image" }` por
 * `{ type: "video" }` no esconde la foto: la desmonta. No quedan restos.
 *
 * `name` es el nombre con el que la película (FlightFilm) encuentra la capa
 * para animarla: "clouds" se agranda con el zoom, "sky-veil" aparece con los
 * beneficios. Si cambiás una capa, dejale el mismo `name` y sigue animándose.
 */

type Common = {
    /** Nombre que usa la película para animar esta capa ("clouds", "sky-veil"). */
    name?: string;
    /** Opacidad inicial de la capa, 0–1. La película puede cambiarla. */
    opacity?: number;
};

export type Layer =
    | ({ type: 'color'; value: string } & Common)
    | ({ type: 'gradient'; value: string } & Common)
    | ({
          type: 'image';
          src: string;
          /** `object-fit`. Por defecto "cover". */
          fit?: 'cover' | 'contain' | 'fill';
          /** `object-position`: "center", "bottom", "50% 20%"… */
          position?: string;
      } & Common)
    | ({
          type: 'video';
          src: string;
          /** La imagen que se ve mientras carga, y la única si se pide menos movimiento. */
          poster: string;
      } & Common);

type Props = {
    layers: Layer[];
    className?: string;
};

export function SectionBackdrop({ layers, className = '' }: Props) {
    return (
        <div
            aria-hidden
            className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}
        >
            {layers.map((layer, i) => (
                <LayerNode key={`${layer.type}-${i}`} layer={layer} />
            ))}
        </div>
    );
}

function LayerNode({ layer }: { layer: Layer }) {
    const cls = `${layer.name ?? ''} absolute inset-0 size-full`;
    switch (layer.type) {
        case 'color':
        case 'gradient':
            return (
                <div className={cls} style={{ background: layer.value, opacity: layer.opacity }} />
            );
        case 'image':
            return (
                <img
                    src={layer.src}
                    alt=""
                    className={cls}
                    style={{
                        objectFit: layer.fit ?? 'cover',
                        objectPosition: layer.position,
                        opacity: layer.opacity,
                    }}
                />
            );
        case 'video':
            return <VideoLayer layer={layer} className={cls} />;
    }
}

/* Toda la lógica del video vive acá adentro. Si esta capa deja de estar en
   `BACKGROUNDS`, el componente no se monta y esto no existe: no quedan
   listeners colgados sobre un elemento que ya no está. */
function VideoLayer({
    layer,
    className,
}: {
    layer: Extract<Layer, { type: 'video' }>;
    className: string;
}) {
    const ref = useRef<HTMLVideoElement>(null);

    useEffect(() => {
        const video = ref.current;
        if (!video) return;
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            video.pause();
            return;
        }
        void video.play().catch(() => {});
    }, [layer.src]);

    return (
        <video
            ref={ref}
            src={layer.src}
            poster={layer.poster}
            muted
            loop
            playsInline
            preload="auto"
            autoPlay
            className={`${className} object-cover`}
            style={{ opacity: layer.opacity }}
        />
    );
}
