import { SmoothScroll } from '@/lib/smoothScroll';
import { activeSections } from '@/sections';
import { Header } from '@/components/Header';
import { ContactFooter } from '@/components/ContactFooter';
import { BookPill } from '@/components/BookPill';

export default function App() {
    return (
        <SmoothScroll>
            <Header />
            <main>
                {activeSections().map(({ id, Component }) => (
                    <Component key={id} />
                ))}
            </main>
            <ContactFooter />
            <BookPill />
            <div className="grain" aria-hidden />
        </SmoothScroll>
    );
}
