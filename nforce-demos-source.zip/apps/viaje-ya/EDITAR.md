# Cómo cambiar este sitio

## Antes que nada: cómo verlo corriendo

Desde la raíz del repositorio, instala Node.js 22 o superior y ejecuta:

```sh
npm ci
npm run dev:viajes
```

Abre la dirección que indica Vite. Para ver los tres diseños juntos, ejecuta `npm run build` y después `npm run preview`.

## Los dos únicos archivos que tenés que tocar

| Archivo              | Qué cambia                                                               |
| -------------------- | ------------------------------------------------------------------------ |
| `src/lib/content.ts` | Textos, teléfono, correo, CTA, imágenes, fondo, cifras y duración        |
| `src/index.css`      | Colores, tipografías y estilos                                           |
| `src/sections.ts`    | Orden y activación de secciones; no hace falta para cambios de contenido |

Los archivos están dentro de `apps/viaje-ya/`. Las direcciones originales de imágenes se concentran en `src/lib/assets.ts`.

## Las 3 cosas que vas a querer cambiar

1. **Marca y contacto:** edita `BRAND`, `CTA` y `NAV` en `content.ts`. Un CTA con `href: '#'` utiliza el correo de la marca.
2. **Colores:** modifica los tokens de `@theme static` en `index.css`. Las animaciones también los consultan; no agregues colores sueltos en los componentes.
3. **Fondo:** edita `BACKGROUNDS.film`. La capa `clouds` acepta imagen, video, color o degradado. Mantén los nombres `clouds` y `sky-veil` porque la animación los identifica.

Para usar un video como fondo:

```ts
{ type: 'video', src: 'https://tu-dominio/fondo.mp4', poster: 'https://tu-dominio/inicio.jpg', name: 'clouds' }
```

Usa un poster y un archivo optimizado. El diseño original utiliza imágenes y no necesita un video.

## Comandos listos para copiar y pegar

Estos pedidos sirven como instrucciones para el desarrollador o asistente:

1. Cambiá las nubes por esta foto: [URL], conservando el nombre de capa clouds.
2. Poné un video en vez de las nubes, usando [MP4] y [POSTER].
3. Cambiá el manifiesto por este texto: [TEXTO].
4. Cambiá los números de la ficha del itinerario por estos: [DATOS].
5. Cambiá las etiquetas de los cuatro pines por [ETIQUETAS], sin mover sus coordenadas.
6. Hacé la película más corta reduciendo FILM_LENGTH en computadora y celular.
7. Cambiá el naranja por [COLOR] en los tokens del tema.
8. Poné el título delante del avión dejando planeCutout vacío.
9. Cambiá el teléfono y correo de BRAND por [CONTACTO].
10. Agregá una sección de contacto después de la película, sin partir su timeline.

## Lo que NO es fácil en este sitio

La ventanilla y su recorte están medidos sobre una imagen concreta. `WINDOW_GLASS` define esa geometría. Cambiar la imagen requiere volver a medir el vidrio y verificar móvil y escritorio.

El avión, su recorte y el mapa tienen el mismo encuadre. Cambiarlos por imágenes no alineadas rompe la transición. `PLANE_FIT` y `PIN_POS` pertenecen al componente `FlightFilm.tsx`.

La experiencia es una única película con un timeline maestro. Separarla en varios timelines con pin produce saltos y cambia la composición. Pide mantener `FlightFilm` como una unidad al modificar las transiciones.

## Si algo se rompe

Vuelve al último commit funcional y ejecuta `npm ci` y `npm run build`. Si falta una imagen, verifica primero su dirección en `assets.ts`. Si el contenido desaparece durante el recorrido, revisa nombres de capas y marcas del timeline antes de cambiar el CSS.

Antes de publicar: recorre inicio, manifiesto, beneficios, avión, cifras y mapa, tanto hacia abajo como hacia arriba, y comprueba el resultado en móvil.
