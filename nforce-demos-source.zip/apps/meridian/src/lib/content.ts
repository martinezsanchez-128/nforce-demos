const CDN = 'https://d8j0ntlcm91z4.cloudfront.net/user_3Bd1EO6EIHxSqCgleKKy9qZ3l1v/';

export const navigation = [
    { label: 'Espacios', href: '#espacios' },
    { label: 'Galería', href: '#galeria' },
    { label: 'Amenidades', href: '#amenidades' },
    { label: 'Contacto', href: '#contacto' },
];

/** Copias locales con fotogramas clave frecuentes para recorrer el video en ambos sentidos. */
export const films = [
    {
        id: 'hero',
        video: './assets/arrival.mp4',
        poster: './assets/arrival.jpg',
        eyebrow: 'La Llegada · Aérea',
        title: 'Una nueva perspectiva de Nuevo León',
    },
    {
        id: 'recibidor',
        video: './assets/entrance.mp4',
        poster: './assets/entrance.jpg',
        eyebrow: 'El Recibidor',
        title: 'Un umbral, no una puerta',
        copy: 'Cada llegada empieza con un gesto de mármol y luz, antes de que la puerta ceda al resto de la residencia.',
    },
    {
        id: 'flujo',
        video: './assets/flow.mp4',
        poster: './assets/flow.jpg',
        eyebrow: 'El Flujo',
        title: 'Donde la casa respira',
        copy: 'Los ambientes se disuelven unos en otros: living, comedor y terraza comparten un mismo aire, una misma luz.',
    },
    {
        id: 'terraza',
        video: './assets/terrace.mp4',
        poster: './assets/terrace.jpg',
        eyebrow: 'La Terraza',
        title: 'El cielo como living',
    },
];

export const spaces = [
    {
        icon: 'sofa',
        title: 'Living Panorámico',
        description: 'Ventanales de piso a techo con vistas panorámicas de la ciudad.',
    },
    {
        icon: 'bed',
        title: 'Suite Principal',
        description: 'Dormitorio principal con vestidor y baño en suite.',
    },
    {
        icon: 'waves',
        title: 'Terraza Infinita',
        description: 'Alberca infinita envolvente sobre el horizonte de la ciudad.',
    },
] as const;

export const statistics = [
    { icon: 'bed', label: 'Recámaras', value: 4 },
    { icon: 'bath', label: 'Baños', value: 5.5 },
    { icon: 'ruler', label: 'Superficie', value: 669, suffix: ' m²' },
    { icon: 'key', label: 'Acceso', display: 'Elevador privado' },
] as const;

export const gallery = [
    [
        'hf_20260705_032822_8e7b22e3-9b3c-4791-9720-283cb479943c.png',
        'Cocina de chef con mármol italiano',
    ],
    ['hf_20260705_032832_f204f72d-3f1d-4b26-bea4-1ad12d8abbea.png', 'Baño principal en suite'],
    ['hf_20260705_032841_fdf5f2d1-03b2-4f0b-ab00-bff72c37fa59.png', 'Dormitorio principal'],
    ['hf_20260705_032849_35826a41-1cce-44ef-bdd6-a05d1d0a5265.png', 'Detalle de mármol italiano'],
    [
        'hf_20260705_032859_beff3304-d8bc-4b2d-8a8b-07a5d768760d.png',
        'Vista nocturna de la ciudad · Imagen ilustrativa',
    ],
    [
        'hf_20260705_032907_583226f3-2a47-4c59-abc0-d4d5d0ca9ae4.png',
        'Fachada de la torre al atardecer',
    ],
].map(([file, alt]) => ({ src: CDN + file, alt }));

export const amenities = [
    'Elevador privado con acceso por llave',
    'Mayordomo disponible 24 horas',
    'Cava de vinos climatizada',
    'Spa privado con sauna',
    'Alberca infinita en terraza',
    'Cocina equipada con línea profesional',
    'Domótica integrada (smart home)',
    'Seguridad biométrica',
];

export const agent = {
    name: 'NFORCE Technologies',
    role: 'Diseño web para inmobiliarias · Nuevo León, México',
    phone: '+52 81 3594 5656',
    email: 'cdms28@hotmail.com',
    image: CDN + 'hf_20260705_033842_db59adc8-1416-4601-85b6-e6b48459026e.png',
};
