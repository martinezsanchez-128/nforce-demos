import { createContext, useContext, useEffect, useRef, type ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';

gsap.registerPlugin(ScrollTrigger);
const ScrollContext = createContext<{ goTo: (selector: string) => void }>({ goTo: () => {} });

export function SmoothScrollProvider({ children }: { children: ReactNode }) {
    const lenisRef = useRef<Lenis | null>(null);

    useEffect(() => {
        if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        const lenis = new Lenis({ lerp: 0.09, smoothWheel: true });
        lenisRef.current = lenis;
        lenis.on('scroll', ScrollTrigger.update);
        const tick = (time: number) => lenis.raf(time * 1000);
        gsap.ticker.add(tick);
        gsap.ticker.lagSmoothing(0);
        return () => {
            gsap.ticker.remove(tick);
            lenis.destroy();
            lenisRef.current = null;
        };
    }, []);

    function goTo(selector: string) {
        const target = document.querySelector<HTMLElement>(selector);
        if (!target) return;
        if (lenisRef.current) lenisRef.current.scrollTo(target, { offset: -72 });
        else
            target.scrollIntoView({
                behavior: matchMedia('(prefers-reduced-motion: reduce)').matches
                    ? 'instant'
                    : 'smooth',
            });
    }

    return <ScrollContext.Provider value={{ goTo }}>{children}</ScrollContext.Provider>;
}

export const useLenis = () => useContext(ScrollContext);
