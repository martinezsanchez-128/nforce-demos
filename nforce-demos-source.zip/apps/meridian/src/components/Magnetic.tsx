import { motion, useMotionValue, useSpring, useReducedMotion } from 'motion/react';
import type { ReactNode, MouseEvent } from 'react';

export function Magnetic({
    children,
    className = 'inline-block',
    strength = 0.35,
}: {
    children: ReactNode;
    className?: string;
    strength?: number;
}) {
    const x = useMotionValue(0),
        y = useMotionValue(0);
    const springX = useSpring(x, { stiffness: 150, damping: 15, mass: 0.2 });
    const springY = useSpring(y, { stiffness: 150, damping: 15, mass: 0.2 });
    const reduced = useReducedMotion();
    function move(event: MouseEvent<HTMLDivElement>) {
        if (reduced || !matchMedia('(hover: hover)').matches) return;
        const bounds = event.currentTarget.getBoundingClientRect();
        x.set((event.clientX - bounds.left - bounds.width / 2) * strength);
        y.set((event.clientY - bounds.top - bounds.height / 2) * strength);
    }
    return (
        <motion.div
            className={className}
            onMouseMove={move}
            onMouseLeave={() => {
                x.set(0);
                y.set(0);
            }}
            style={{ x: springX, y: springY }}
        >
            {children}
        </motion.div>
    );
}
