import { motion, useReducedMotion } from 'motion/react';
export function SectionCurtain() {
    const reduced = useReducedMotion();
    return (
        <motion.div
            aria-hidden
            className="pointer-events-none absolute inset-0 z-30 bg-navy"
            style={{ transformOrigin: 'top' }}
            initial={{ scaleY: reduced ? 0 : 1 }}
            whileInView={{ scaleY: 0 }}
            viewport={{ once: true, amount: 0.1 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
        />
    );
}
