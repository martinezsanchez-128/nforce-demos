import { useEffect, useRef } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

type Film = {
    id: string;
    video: string;
    poster: string;
    eyebrow: string;
    title: string;
    copy?: string;
};
const childVariants = {
    hidden: { opacity: 0, y: 24 },
    show: { opacity: 1, y: 0, transition: { duration: 0.7 } },
};

export function ScrubSection({ section }: { section: Film }) {
    const wrapper = useRef<HTMLDivElement>(null),
        stage = useRef<HTMLElement>(null),
        videoRef = useRef<HTMLVideoElement>(null);
    const reduced = useReducedMotion();

    useEffect(() => {
        const video = videoRef.current!,
            node = wrapper.current!;
        let alive = true,
            targetTime = 0,
            pending = false,
            blobUrl = '',
            trigger: ScrollTrigger | undefined;
        const abort = new AbortController();

        function seek() {
            if (!Number.isFinite(video.duration)) return;
            if (video.seeking) {
                pending = true;
                return;
            }
            const time = Math.min(Math.max(0, targetTime), Math.max(0, video.duration - 0.04));
            if (Math.abs(video.currentTime - time) > 0.015) video.currentTime = time;
        }
        function onSeeked() {
            if (pending) {
                pending = false;
                seek();
            }
        }
        function wire() {
            if (!alive || trigger || !Number.isFinite(video.duration)) return;
            trigger = ScrollTrigger.create({
                trigger: node,
                start: 'top top',
                end: '+=120%',
                pin: stage.current,
                pinSpacing: false,
                scrub: reduced ? true : 1,
                invalidateOnRefresh: true,
                onUpdate: (self) => {
                    targetTime = self.progress * (video.duration - 0.04);
                    seek();
                },
            });
            ScrollTrigger.refresh();
        }
        video.addEventListener('seeked', onSeeked);
        video.addEventListener('loadedmetadata', wire);

        // Descarga solo cerca de la sección; el espacio reservado evita saltos al crear el pin.
        const observer = new IntersectionObserver(
            async ([entry]) => {
                if (!entry.isIntersecting) return;
                observer.disconnect();
                try {
                    const response = await fetch(section.video, { signal: abort.signal });
                    if (!response.ok) throw new Error('Video unavailable');
                    const blob = await response.blob();
                    if (!alive) return;
                    blobUrl = URL.createObjectURL(blob);
                    video.src = blobUrl;
                } catch (error) {
                    if (alive && !(error instanceof DOMException && error.name === 'AbortError'))
                        video.src = section.video;
                }
            },
            { rootMargin: '150% 0px' },
        );
        observer.observe(node);
        return () => {
            alive = false;
            abort.abort();
            observer.disconnect();
            trigger?.kill();
            video.removeEventListener('loadedmetadata', wire);
            video.removeEventListener('seeked', onSeeked);
            if (blobUrl) URL.revokeObjectURL(blobUrl);
        };
    }, [section.video, reduced]);

    return (
        <div ref={wrapper} className="scrub-region">
            <section
                ref={stage}
                id={section.id}
                className="scrub-stage relative h-screen w-full overflow-hidden bg-neutral-900"
            >
                <video
                    ref={videoRef}
                    poster={section.poster}
                    muted
                    playsInline
                    preload="none"
                    className="absolute inset-0 h-full w-full object-cover"
                    aria-hidden
                />
                <div className="absolute inset-0 bg-black/35" />
                <motion.div
                    className="relative z-10 flex h-full flex-col items-start justify-end px-6 pb-24 md:px-16"
                    initial={reduced ? false : 'hidden'}
                    whileInView="show"
                    viewport={{ once: true, amount: 0.6 }}
                    variants={{
                        show: { transition: { staggerChildren: 0.18, delayChildren: 0.1 } },
                    }}
                >
                    <motion.span
                        variants={childVariants}
                        className="mb-4 text-sm uppercase tracking-[0.3em] text-gold"
                    >
                        {section.eyebrow}
                    </motion.span>
                    <motion.h2
                        variants={childVariants}
                        className="max-w-3xl font-serif text-4xl leading-[1.14] text-white md:text-6xl"
                    >
                        {section.title}
                    </motion.h2>
                    {section.copy && (
                        <motion.p
                            variants={childVariants}
                            className="mt-5 max-w-xl text-base leading-relaxed text-white/80 md:text-lg"
                        >
                            {section.copy}
                        </motion.p>
                    )}
                </motion.div>
                <div
                    className="absolute bottom-7 right-6 text-[10px] uppercase tracking-[0.25em] text-white/70 md:right-16"
                    aria-hidden
                >
                    THE MERIDIAN RESIDENCES
                </div>
            </section>
        </div>
    );
}
