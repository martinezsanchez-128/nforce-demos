import { useEffect, useState, type FormEvent } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
    ArrowUpRight,
    Bath,
    BedDouble,
    Check,
    KeyRound,
    Menu,
    Ruler,
    Sofa,
    Waves,
    X,
} from 'lucide-react';
import { films, navigation, spaces, statistics, gallery, amenities, agent } from './lib/content';
import { SmoothScrollProvider, useLenis } from './lib/SmoothScroll';
import { Magnetic } from './components/Magnetic';
import { SectionCurtain } from './components/SectionCurtain';
import { ScrubSection } from './components/ScrubSection';

const icons = { sofa: Sofa, bed: BedDouble, waves: Waves, bath: Bath, ruler: Ruler, key: KeyRound };

function Navigation() {
    const [scrolled, setScrolled] = useState(false);
    const [open, setOpen] = useState(false);
    const { goTo } = useLenis();
    useEffect(() => {
        const update = () => setScrolled(window.scrollY > 24);
        update();
        window.addEventListener('scroll', update, { passive: true });
        return () => window.removeEventListener('scroll', update);
    }, []);
    function navigate(href: string) {
        setOpen(false);
        goTo(href);
    }
    return (
        <header className={`navigation ${scrolled || open ? 'solid' : ''}`}>
            <a
                className="wordmark"
                href="#hero"
                onClick={(event) => {
                    event.preventDefault();
                    navigate('#hero');
                }}
            >
                THE MERIDIAN<span>RESIDENCES · NUEVO LEÓN, MÉXICO</span>
            </a>
            <nav aria-label="Navegación principal" className={open ? 'is-open' : ''}>
                {navigation.map((item) => (
                    <a
                        key={item.href}
                        href={item.href}
                        onClick={(event) => {
                            event.preventDefault();
                            navigate(item.href);
                        }}
                    >
                        {item.label}
                    </a>
                ))}
            </nav>
            <button
                className="menu-button"
                aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
                aria-expanded={open}
                onClick={() => setOpen(!open)}
            >
                {open ? <X /> : <Menu />}
            </button>
        </header>
    );
}

function Gallery() {
    const [selected, setSelected] = useState<number | null>(null);
    useEffect(() => {
        if (selected === null) return;
        const close = (event: KeyboardEvent) => {
            if (event.key === 'Escape') setSelected(null);
        };
        window.addEventListener('keydown', close);
        return () => window.removeEventListener('keydown', close);
    }, [selected]);
    return (
        <>
            <div className="gallery-grid">
                {gallery.map((image, index) => (
                    <button
                        key={image.src}
                        className="gallery-image"
                        onClick={() => setSelected(index)}
                        aria-label={`Ampliar: ${image.alt}`}
                    >
                        <img src={image.src} alt={image.alt} loading="lazy" />
                        <span>
                            {image.alt}
                            <ArrowUpRight size={18} />
                        </span>
                    </button>
                ))}
            </div>
            <AnimatePresence>
                {selected !== null && (
                    <motion.div
                        className="lightbox"
                        role="dialog"
                        aria-modal="true"
                        aria-label={gallery[selected].alt}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={() => setSelected(null)}
                    >
                        <button
                            autoFocus
                            className="lightbox-close"
                            aria-label="Cerrar imagen"
                            onClick={() => setSelected(null)}
                        >
                            <X />
                        </button>
                        <img
                            src={gallery[selected].src}
                            alt={gallery[selected].alt}
                            onClick={(event) => event.stopPropagation()}
                        />
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
}

function Contact() {
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);
    function submit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        const data = new FormData(event.currentTarget);
        if (['name', 'email', 'phone'].some((key) => !String(data.get(key) || '').trim())) {
            setError('Completa nombre, email y teléfono para continuar.');
            return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(data.get('email')))) {
            setError('Ingresa un email válido.');
            return;
        }
        setError('');
        setSuccess(true);
    }
    return (
        <section id="contacto" className="section contact-section">
            <SectionCurtain />
            <div>
                <p className="eyebrow">Una conversación privada</p>
                <h2>
                    Tu próxima dirección
                    <br />
                    <em>empieza aquí.</em>
                </h2>
                <p className="section-copy">
                    Coordina una visita y conoce una residencia que se vive de otra manera.
                </p>
                <AnimatePresence mode="wait">
                    {success ? (
                        <motion.div
                            key="success"
                            className="success-message"
                            initial={{ opacity: 0, y: 12 }}
                            animate={{ opacity: 1, y: 0 }}
                        >
                            <Check />
                            <h3>Todo listo para dar el siguiente paso.</h3>
                            <p>
                                Esta es una demostración. Tus datos no se enviaron ni se guardaron.
                            </p>
                            <button onClick={() => setSuccess(false)}>Volver al formulario</button>
                        </motion.div>
                    ) : (
                        <motion.form
                            key="form"
                            noValidate
                            onSubmit={submit}
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                        >
                            <div className="form-row">
                                <label>
                                    Nombre
                                    <input
                                        name="name"
                                        autoComplete="name"
                                        placeholder="Tu nombre"
                                        required
                                    />
                                </label>
                                <label>
                                    Email
                                    <input
                                        name="email"
                                        type="email"
                                        autoComplete="email"
                                        placeholder="tu@email.com"
                                        required
                                    />
                                </label>
                            </div>
                            <label>
                                Teléfono
                                <input
                                    name="phone"
                                    type="tel"
                                    autoComplete="tel"
                                    placeholder="+52 81 …"
                                    required
                                />
                            </label>
                            <label>
                                Mensaje
                                <textarea
                                    name="message"
                                    rows={3}
                                    placeholder="Cuéntanos qué te gustaría conocer"
                                />
                            </label>
                            <p className="form-error" role="alert">
                                {error}
                            </p>
                            <Magnetic>
                                <button className="button" type="submit">
                                    Agendar una visita <ArrowUpRight size={18} />
                                </button>
                            </Magnetic>
                            <p className="demo-note">
                                Formulario de muestra · No envía información.
                            </p>
                        </motion.form>
                    )}
                </AnimatePresence>
            </div>
            <aside className="agent-card">
                <img
                    src={agent.image}
                    alt="Imagen ilustrativa de atención inmobiliaria"
                    loading="lazy"
                />
                <div>
                    <p className="eyebrow">Atención personal</p>
                    <h3>{agent.name}</h3>
                    <p>{agent.role}</p>
                    <p>
                        <a href="tel:+528135945656">{agent.phone}</a>
                    </p>
                    <p>
                        <a href={`mailto:${agent.email}`}>{agent.email}</a>
                    </p>
                    <p>Nuevo León, México</p>
                    <p>
                        <a
                            href="https://wa.me/528135945656?text=Hola%20NFORCE%2C%20me%20interesa%20el%20dise%C3%B1o%20inmobiliario."
                            target="_blank"
                            rel="noopener noreferrer"
                        >
                            Contactar a NFORCE por WhatsApp
                        </a>
                    </p>
                    <p className="demo-note">
                        Contacto real de NFORCE Technologies. Propiedad e imágenes ilustrativas.
                    </p>
                </div>
            </aside>
        </section>
    );
}

function Experience() {
    const { goTo } = useLenis();
    const reduced = useReducedMotion();
    return (
        <>
            <Navigation />
            <main>
                <ScrubSection section={films[0]} />
                <section id="espacios" className="section">
                    <SectionCurtain />
                    <p className="eyebrow">Diseñada para vivir distinto</p>
                    <h2>
                        El lujo de tener
                        <br />
                        <em>espacio para todo.</em>
                    </h2>
                    <div className="spaces-grid">
                        {spaces.map((item) => {
                            const Icon = icons[item.icon];
                            return (
                                <article className="space-card" key={item.title}>
                                    <Icon strokeWidth={1.2} size={36} />
                                    <h3>{item.title}</h3>
                                    <p>{item.description}</p>
                                </article>
                            );
                        })}
                    </div>
                </section>
                <section className="statistics section">
                    <SectionCurtain />
                    {statistics.map((item) => {
                        const Icon = icons[item.icon];
                        return (
                            <div key={item.label}>
                                <Icon size={22} strokeWidth={1.3} />
                                <strong>
                                    {'value' in item ? item.value : item.display}
                                    {'suffix' in item ? item.suffix : ''}
                                </strong>
                                <span>{item.label}</span>
                            </div>
                        );
                    })}
                </section>
                <ScrubSection section={films[1]} />
                <ScrubSection section={films[2]} />
                <section id="galeria" className="section">
                    <SectionCurtain />
                    <div className="section-heading">
                        <div>
                            <p className="eyebrow">Una mirada más cerca</p>
                            <h2>
                                La belleza está
                                <br />
                                <em>en los detalles.</em>
                            </h2>
                        </div>
                        <p className="section-copy">
                            Materiales nobles, proporciones generosas y una ciudad que se vuelve
                            parte de tu casa.
                        </p>
                    </div>
                    <Gallery />
                </section>
                <section id="amenidades" className="section amenities-section">
                    <SectionCurtain />
                    <p className="eyebrow">Sin concesiones</p>
                    <h2>
                        Todo lo extraordinario.
                        <br />
                        <em>Todos los días.</em>
                    </h2>
                    <div className="amenities-grid">
                        {amenities.map((item, index) => (
                            <div key={item}>
                                <span>{String(index + 1).padStart(2, '0')}</span>
                                <p>{item}</p>
                                <Check size={18} />
                            </div>
                        ))}
                    </div>
                </section>
                <ScrubSection section={films[3]} />
                <section className="section price-section">
                    <SectionCurtain />
                    <p className="eyebrow">Una residencia irrepetible</p>
                    <h2>Un nuevo punto de vista.</h2>
                    <motion.p
                        className="price"
                        initial={reduced ? false : { opacity: 0, y: 20 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true }}
                    >
                        MXN $125,000,000
                    </motion.p>
                    <p>
                        669 m² de una vida por encima de lo esperado. Precio ilustrativo en pesos
                        mexicanos.
                    </p>
                    <Magnetic>
                        <button className="button" onClick={() => goTo('#contacto')}>
                            Solicitar información <ArrowUpRight size={18} />
                        </button>
                    </Magnetic>
                </section>
                <Contact />
            </main>
            <footer>
                <a
                    className="wordmark"
                    href="#hero"
                    onClick={(event) => {
                        event.preventDefault();
                        goTo('#hero');
                    }}
                >
                    THE MERIDIAN<span>RESIDENCES · NUEVO LEÓN, MÉXICO</span>
                </a>
                <p>Una perspectiva diferente de la ciudad.</p>
                <small>
                    Concepto de demostración · NFORCE Technologies · Imágenes ilustrativas
                </small>
                <a href="../">Ver más diseños</a>
            </footer>
            <div className="grain" aria-hidden />
        </>
    );
}

export default function App() {
    return (
        <SmoothScrollProvider>
            <Experience />
        </SmoothScrollProvider>
    );
}
