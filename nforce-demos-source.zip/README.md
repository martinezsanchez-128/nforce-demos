# NFORCE · Colección de experiencias

Tres demostraciones independientes, reunidas en un catálogo para compartir con clientes.

| Diseño                  | Sector                | Implementación                                                       |
| ----------------------- | --------------------- | -------------------------------------------------------------------- |
| ViajeYa                 | Agencia de viajes     | React 19, TypeScript, GSAP y Lenis; película construida con imágenes |
| The Meridian Residences | Inmobiliaria          | React 19, TypeScript, GSAP, Motion y videos controlados por scroll   |
| Braza                   | Restaurante de cortes | Un HTML legible con CSS y JavaScript; video controlado por scroll    |

## Preparación

Node.js 22 o superior y npm.

```sh
npm ci
npm run build
npm run preview
```

La vista previa completa se abre en `http://127.0.0.1:8778/`. Para desarrollar con recarga automática, usa `npm run dev:viajes` o `npm run dev:meridian`.

## Organización

- `apps/viaje-ya/`: componentes, contenido centralizado y estilos del viaje.
- `apps/meridian/`: residencia, componentes y archivos de video locales.
- `apps/braza/`: HTML independiente y película local.
- `catalog/`: portada de la colección.
- `scripts/`: servidor de vista previa y ensamblado.
- `site/`: salida generada; no se edita ni se versiona.
- `.github/workflows/pages.yml`: compila y publica la salida mediante GitHub Pages.

Los nombres de archivos y componentes describen su función. El código fuente conserva separación, indentación y comentarios donde explican decisiones. Vite comprime únicamente los archivos de entrega para mejorar la carga.

## Publicación

En Settings → Pages, selecciona **GitHub Actions** como origen. El workflow instala desde el lockfile, comprueba TypeScript, compila y publica `site/`. No se necesitan claves ni servicios de pago. Cada diseño utiliza rutas relativas y puede alojarse bajo el nombre del repositorio.

## Edición

ViajeYa: consultar [su guía](apps/viaje-ya/EDITAR.md). Textos en `src/lib/content.ts`, recursos en `src/lib/assets.ts` y tema en `src/index.css`.

Meridian: textos y recursos en `apps/meridian/src/lib/content.ts`; diseño en `src/index.css`; componentes en `src/components/` y secciones en `src/App.tsx`.

Braza: HTML, estilos y comportamiento agrupados en `apps/braza/index.html`. Sus medios están en `assets/`.

Los videos se sirven localmente, sin audio ni reproducción automática. Sus fotogramas clave frecuentes permiten recorrerlos hacia adelante y atrás. Cada video tiene una imagen inicial para evitar una primera pantalla vacía.

## Alcance

Son ejemplos visuales: los precios, marcas, propiedades y cifras son ilustrativos; los contactos corresponden a NFORCE Technologies, en Nuevo León, México. El formulario de Meridian valida en el navegador y muestra una confirmación de demostración; no envía ni almacena datos. Las reservas y la carta de Braza abren diálogos de muestra. ViajeYa y los diálogos de contacto enlazan al WhatsApp real de NFORCE. Teléfono: +52 81 3594 5656. Correo: cdms28@hotmail.com. Ubicación: Nuevo León, México.

Se respetan las preferencias de movimiento reducido. El contenido puede recorrerse con teclado y las galerías tienen textos alternativos. Las imágenes de las referencias se sirven desde su CDN original; los videos se incluyen en el proyecto.

## Referencias adquiridas por el cliente

- [Viaje Ya](https://soypablocarballo.com/motion-ai/viaje-ya/)
- [The Meridian Residences](https://soypablocarballo.com/motion-ai/the-meridian-residences/)
- [Braza](https://soypablocarballo.com/motion-ai/braza/)

Los prompts completos de pago no se incluyen en este repositorio. Este proyecto no concede derechos adicionales sobre las referencias o sus recursos.

## Si usas el archivo ZIP del repositorio publicado

El ZIP incluye el código fuente, los posters y la documentación. Para evitar duplicar películas, los videos se descargan desde la versión publicada con:

```sh
node scripts/restore-media.mjs
npm ci
npm run build
npm run preview
```
